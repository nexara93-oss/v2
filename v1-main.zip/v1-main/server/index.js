import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import { readdirSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import db, { hashPassword, verifyPassword } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.set('trust proxy', true);

// Security headers (helmet not installed — set the key ones manually)
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.removeHeader('X-Powered-By');
  next();
});

// Normalize a client IP — never return 'unknown'; returns null if undetermined.
function getClientIP(req) {
  let raw = null;
  // trust proxy is on: prefer the leftmost X-Forwarded-For entry if present
  const xff = req.headers['x-forwarded-for'];
  if (xff) {
    const first = String(xff).split(',')[0].trim();
    if (first && first !== 'unknown') raw = first;
  }
  if (!raw) raw = req.socket?.remoteAddress || null;
  if (!raw || raw === 'unknown') return null;
  // Normalize IPv6-mapped IPv4 and loopback
  if (raw === '::1') return '127.0.0.1';
  if (raw.startsWith('::ffff:')) raw = raw.slice(7);
  return raw;
}

// Map the students.level label to a level slug ('bac1' / 'bac2' / null)
function mapStudentLevel(level) {
  if (!level) return null;
  const s = String(level).toLowerCase();
  if (s.startsWith('1') || s.includes('1ère') || s.includes('premi')) return 'bac1';
  if (s.startsWith('2') || s.includes('2ème') || s.includes('deuxi')) return 'bac2';
  return null;
}

// ─── Admin authentication ───
const activeAdminTokens = new Set();

function requireAdmin(req, res, next) {
  const token = req.headers['x-admin-token'];
  if (token && activeAdminTokens.has(token)) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

// Simple in-memory rate limiting per IP to slow brute force attempts
const loginAttempts = {};
app.post('/api/admin/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const ip = getClientIP(req);
  const now = Date.now();
  const record = loginAttempts[ip] || { count: 0, windowStart: now };
  if (now - record.windowStart > 15 * 60 * 1000) { record.count = 0; record.windowStart = now; }
  if (record.count >= 10) return res.status(429).json({ error: 'Trop de tentatives. Réessayez plus tard.' });
  record.count++;

  const admin = db.prepare('SELECT * FROM admin WHERE username = ?').get(username || '');
  if (!admin || !verifyPassword(password || '', admin.password_hash)) {
    loginAttempts[ip] = record;
    return res.status(401).json({ error: "Nom d'utilisateur ou mot de passe incorrect" });
  }
  loginAttempts[ip] = { count: 0, windowStart: now };
  const token = crypto.randomBytes(32).toString('hex');
  activeAdminTokens.add(token);
  res.json({ success: true, token, username: admin.username });
});

app.post('/api/admin/auth/logout', (req, res) => {
  activeAdminTokens.delete(req.headers['x-admin-token']);
  res.json({ success: true });
});

// ─── Admin: change password ───
app.post('/api/admin/change-password', requireAdmin, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Mot de passe actuel et nouveau mot de passe requis' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'Le nouveau mot de passe doit contenir au moins 8 caractères' });
  }
  const token = req.headers['x-admin-token'];
  const admin = db.prepare('SELECT * FROM admin WHERE id = (SELECT id FROM admin LIMIT 1)').get();
  if (!admin) {
    return res.status(500).json({ error: 'Erreur interne du serveur' });
  }
  if (!verifyPassword(currentPassword, admin.password_hash)) {
    return res.status(401).json({ error: 'Mot de passe actuel incorrect' });
  }
  db.prepare('UPDATE admin SET password_hash = ? WHERE id = ?').run(hashPassword(newPassword), admin.id);
  activeAdminTokens.delete(token);
  res.json({ success: true, message: 'Mot de passe modifié avec succès. Veuillez vous reconnecter.' });
});

app.get('/api/admin/auth/check', (req, res) => {
  const token = req.headers['x-admin-token'];
  if (token && activeAdminTokens.has(token)) return res.json({ valid: true });
  return res.json({ valid: false });
});

// ─── File Upload ───
const imageStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads/thumbnails'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const videoStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads/videos'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const uploadImage = multer({
  storage: imageStorage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext && mime) return cb(null, true);
    const err = new Error('Seuls les fichiers images sont autorisés');
    err.status = 400;
    cb(err);
  }
});

const uploadVideo = multer({
  storage: videoStorage,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /mp4|webm|ogg|mov|m4v|mkv/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext && mime) return cb(null, true);
    const err = new Error('Seuls les fichiers vidéo sont autorisés');
    err.status = 400;
    cb(err);
  }
});

const pdfStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'uploads/pdfs'));
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const uploadPdf = multer({
  storage: pdfStorage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /pdf/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext && mime) return cb(null, true);
    const err = new Error('Seuls les fichiers PDF sont autorisés');
    err.status = 400;
    cb(err);
  }
});

// Ensure upload directories exist (multer does not create them)
mkdirSync(path.join(__dirname, 'uploads', 'thumbnails'), { recursive: true });
mkdirSync(path.join(__dirname, 'uploads', 'videos'), { recursive: true });
mkdirSync(path.join(__dirname, 'uploads', 'pdfs'), { recursive: true });

app.use('/uploads', (req, res, next) => {
  // Never serve uploads as executable HTML/JS
  res.setHeader('Content-Security-Policy', "default-src 'none'; media-src 'self'");
  next();
}, express.static(path.join(__dirname, 'uploads')));

// Serve hero/slider images dropped into the public/image folder
const heroImagesDir = path.join(__dirname, '..', 'public', 'image');
app.get('/api/hero/images', (req, res) => {
  try {
    const files = readdirSync(heroImagesDir).filter(f =>
      /\.(png|jpe?g|gif|webp|svg|avif)$/i.test(f)
    );
    res.json(files.map(f => `/image/${f}`));
  } catch (e) {
    res.json([]);
  }
});

app.post('/api/admin/upload', requireAdmin, uploadImage.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const url = `/uploads/thumbnails/${req.file.filename}`;
  res.json({ url });
});

app.post('/api/admin/upload/video', requireAdmin, uploadVideo.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const url = `/uploads/videos/${req.file.filename}`;
  res.json({ url, filename: req.file.filename });
});

app.post('/api/admin/upload/pdf', requireAdmin, uploadPdf.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const url = `/uploads/pdfs/${req.file.filename}`;
  res.json({ url, filename: req.file.filename });
});

// ─── Levels ───
app.get('/api/levels', (req, res) => {
  const levels = db.prepare('SELECT * FROM levels').all();
  res.json(levels);
});

app.get('/api/levels/:slug', (req, res) => {
  const level = db.prepare('SELECT * FROM levels WHERE slug = ?').get(req.params.slug);
  if (!level) return res.status(404).json({ error: 'Level not found' });
  res.json(level);
});

// ─── Subjects ───
app.get('/api/subjects', (req, res) => {
  const { level_slug } = req.query;
  let subjects;
  if (level_slug) {
    subjects = db.prepare(`
      SELECT s.*, l.name as level_name, l.slug as level_slug
      FROM subjects s JOIN levels l ON s.level_id = l.id
      WHERE l.slug = ? ORDER BY s.id
    `).all(level_slug);
  } else {
    subjects = db.prepare(`
      SELECT s.*, l.name as level_name, l.slug as level_slug
      FROM subjects s JOIN levels l ON s.level_id = l.id
      ORDER BY l.id, s.id
    `).all();
  }
  res.json(subjects);
});

app.get('/api/subjects/:slug', (req, res) => {
  const subject = db.prepare(`
    SELECT s.*, l.name as level_name, l.slug as level_slug
    FROM subjects s JOIN levels l ON s.level_id = l.id
    WHERE s.slug = ?
  `).get(req.params.slug);
  if (!subject) return res.status(404).json({ error: 'Subject not found' });
  res.json(subject);
});

// ─── Chapters ───
app.get('/api/subjects/:slug/chapters', (req, res) => {
  const subject = db.prepare('SELECT id FROM subjects WHERE slug = ?').get(req.params.slug);
  if (!subject) return res.status(404).json({ error: 'Subject not found' });
  const chapters = db.prepare('SELECT * FROM chapters WHERE subject_id = ? ORDER BY sort_order').all(subject.id);
  res.json(chapters);
});

// ─── Lessons ───
app.get('/api/chapters/:id/lessons', (req, res) => {
  const lessons = db.prepare('SELECT * FROM lessons WHERE chapter_id = ? ORDER BY sort_order').all(req.params.id);
  const result = lessons.map(l => ({
    ...l,
    tags: l.tags ? l.tags.split(',') : [],
  }));
  res.json(result);
});

app.get('/api/lessons/:id', (req, res) => {
  const lesson = db.prepare(`
    SELECT l.*, c.title as chapter_title, c.subject_id,
      (SELECT lv.slug FROM levels lv JOIN subjects s ON s.level_id = lv.id WHERE s.id = c.subject_id) as subject_level_slug
    FROM lessons l JOIN chapters c ON l.chapter_id = c.id
    WHERE l.id = ?
  `).get(req.params.id);
  if (!lesson) return res.status(404).json({ error: 'Lesson not found' });

  const ordered = db.prepare(`
    SELECT l.id, l.title, ch.title as chapter_title
    FROM lessons l
    JOIN chapters ch ON l.chapter_id = ch.id
    WHERE ch.subject_id = ?
    ORDER BY ch.sort_order, l.sort_order
  `).all(lesson.subject_id);

  const idx = ordered.findIndex(l => l.id === lesson.id);
  const next_lesson = idx >= 0 && idx < ordered.length - 1 ? ordered[idx + 1] : null;

  const attachments = db.prepare('SELECT * FROM attachments WHERE lesson_id = ?').all(req.params.id);
  const tags = lesson.tags ? lesson.tags.split(',') : [];
  const thumb = db.prepare('SELECT thumbnail_url FROM video_thumbnails WHERE lesson_id = ? ORDER BY id DESC LIMIT 1').get(req.params.id);

  res.json({ ...lesson, thumbnail_url: thumb ? thumb.thumbnail_url : null, tags, attachments, next_lesson });
});

app.get('/api/subjects/:slug/lessons', (req, res) => {
  const subject = db.prepare('SELECT id FROM subjects WHERE slug = ?').get(req.params.slug);
  if (!subject) return res.status(404).json({ error: 'Subject not found' });

  const lessons = db.prepare(`
    SELECT l.*, ch.title as chapter_title,
      (SELECT vt.thumbnail_url FROM video_thumbnails vt
       WHERE vt.lesson_id = l.id ORDER BY vt.id DESC LIMIT 1) as thumbnail_url
    FROM lessons l
    JOIN chapters ch ON l.chapter_id = ch.id
    WHERE ch.subject_id = ?
    ORDER BY ch.sort_order, l.sort_order
  `).all(subject.id);

  const result = lessons.map(l => ({
    ...l,
    tags: l.tags ? l.tags.split(',') : [],
  }));
  res.json(result);
});

// ─── Teachers ───
app.get('/api/teachers', (req, res) => {
  const teachers = db.prepare('SELECT * FROM teachers').all();
  res.json(teachers);
});

// ─── Admin: Levels CRUD ───
app.get('/api/admin/levels', requireAdmin, (req, res) => {
  const levels = db.prepare('SELECT * FROM levels ORDER BY id').all();
  res.json(levels);
});

app.post('/api/admin/levels', requireAdmin, (req, res) => {
  const { name, slug, icon, description } = req.body || {};
  if (!name || !slug) return res.status(400).json({ error: 'Nom et slug requis' });
  const existing = db.prepare('SELECT id FROM levels WHERE slug = ?').get(slug);
  if (existing) return res.status(409).json({ error: 'Ce slug existe déjà' });
  const result = db.prepare('INSERT INTO levels (name, slug, icon, description) VALUES (?, ?, ?, ?)').run(name, slug, icon || null, description || null);
  res.json({ success: true, id: result.lastInsertRowid });
});

app.put('/api/admin/levels/:id', requireAdmin, (req, res) => {
  const { name, slug, icon, description } = req.body || {};
  if (!name || !slug) return res.status(400).json({ error: 'Nom et slug requis' });
  const level = db.prepare('SELECT id FROM levels WHERE id = ?').get(req.params.id);
  if (!level) return res.status(404).json({ error: 'Niveau introuvable' });
  const dup = db.prepare('SELECT id FROM levels WHERE slug = ? AND id != ?').get(slug, req.params.id);
  if (dup) return res.status(409).json({ error: 'Ce slug existe déjà' });
  db.prepare('UPDATE levels SET name = ?, slug = ?, icon = ?, description = ? WHERE id = ?').run(name, slug, icon || null, description || null, req.params.id);
  res.json({ success: true });
});

app.delete('/api/admin/levels/:id', requireAdmin, (req, res) => {
  const level = db.prepare('SELECT id FROM levels WHERE id = ?').get(req.params.id);
  if (!level) return res.status(404).json({ error: 'Niveau introuvable' });
  const hasSubjects = db.prepare('SELECT COUNT(*) c FROM subjects WHERE level_id = ?').get(req.params.id).c;
  if (hasSubjects > 0) return res.status(400).json({ error: 'Impossible de supprimer un niveau contenant des matières' });
  db.prepare('DELETE FROM levels WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ─── Admin: Dashboard Stats ───
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const totalStudents = db.prepare('SELECT COUNT(*) as count FROM students').get().count;
  const activeStudents = db.prepare("SELECT COUNT(*) as count FROM students WHERE status = 'active'").get().count;
  const overdueStudents = db.prepare("SELECT COUNT(*) as count FROM students WHERE status = 'overdue'").get().count;
  const totalLessons = db.prepare('SELECT COUNT(*) as count FROM lessons').get().count;
  const totalSubjects = db.prepare('SELECT COUNT(*) as count FROM subjects').get().count;
  const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get().count;

  const byLevel = db.prepare(`
    SELECT level, COUNT(*) as students,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active
    FROM students GROUP BY level
  `).all();

  res.json({
    totalStudents,
    activeStudents,
    overdueStudents,
    totalLessons,
    totalSubjects,
    totalUsers,
    byLevel,
  });
});

// ─── Admin: Students ───
app.get('/api/admin/students', requireAdmin, (req, res) => {
  const students = db.prepare(`
    SELECT s.*, u.ip_address, u.last_login_ip
    FROM students s
    LEFT JOIN users u ON u.id = s.user_id
    ORDER BY s.id DESC
  `).all();
  res.json(students);
});

app.post('/api/admin/students', requireAdmin, (req, res) => {
  const { name, email, level } = req.body;
  if (!name || !email || !level) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  // Generate random password: 14 chars with letters, numbers, symbols
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
  let password = '';
  for (let i = 0; i < 14; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }

  try {
    // Create user account for login
    const userResult = db.prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)').run(name, email, hashPassword(password));

    const today = new Date().toISOString().slice(0, 10);
    const next = new Date();
    next.setDate(next.getDate() + 30);
    const nextDue = next.toISOString().slice(0, 10);
    const result = db.prepare(
      'INSERT INTO students (name, email, level, user_id, paid_on, next_due, status) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(name, email, level, userResult.lastInsertRowid, today, nextDue, 'active');

    res.json({
      id: result.lastInsertRowid,
      name,
      email,
      level,
      user_id: userResult.lastInsertRowid,
      paid_on: today,
      next_due: nextDue,
      status: 'active',
      password,
    });
  } catch (e) {
    if (e.message.includes('UNIQUE')) {
      return res.status(409).json({ error: "Cet e-mail existe déjà" });
    }
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/admin/students/:id', requireAdmin, (req, res) => {
  const { status, paid_on, next_due } = req.body;
  const student = db.prepare('SELECT * FROM students WHERE id = ?').get(req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  db.prepare('UPDATE students SET status = ?, paid_on = ?, next_due = ? WHERE id = ?')
    .run(status || student.status, paid_on || student.paid_on, next_due || student.next_due, req.params.id);
  res.json({ success: true });
});

app.delete('/api/admin/students/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM students WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Reset the IP lock so the student can log in from a new device/IP
app.post('/api/admin/students/:id/reset-ip', requireAdmin, (req, res) => {
  const student = db.prepare('SELECT user_id FROM students WHERE id = ?').get(req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });
  if (student.user_id) {
    db.prepare('UPDATE users SET ip_address = NULL, last_login_ip = NULL WHERE id = ?').run(student.user_id);
  }
  res.json({ success: true });
});

// ─── Admin: Media ───
app.get('/api/admin/media', requireAdmin, (req, res) => {
  const files = db.prepare('SELECT * FROM media_files ORDER BY uploaded_at DESC').all();
  res.json(files);
});

app.post('/api/admin/media', requireAdmin, (req, res) => {
  const { name, type, category, size, file_url } = req.body;
  if (!name || !type || !category) {
    return res.status(400).json({ error: 'Required fields missing' });
  }
  const result = db.prepare(
    'INSERT INTO media_files (name, type, category, size, file_url) VALUES (?, ?, ?, ?, ?)'
  ).run(name, type, category, size || '', file_url || '');
  res.json({ id: result.lastInsertRowid, name, type, category, size, file_url });
});

app.delete('/api/admin/media/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM media_files WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ─── Admin: Watch History ───
app.get('/api/admin/watch-history', requireAdmin, (req, res) => {
  const history = db.prepare(`
    SELECT wh.*, u.name as user_name, u.email, l.title as lesson_title
    FROM watch_history wh
    JOIN users u ON wh.user_id = u.id
    JOIN lessons l ON wh.lesson_id = l.id
    ORDER BY wh.watched_at DESC
  `).all();
  res.json(history);
});

app.get('/api/admin/user-activity', requireAdmin, (req, res) => {
  const activity = db.prepare(`
    SELECT u.id, u.name, u.email,
      COUNT(wh.id) as lessons_watched,
      COALESCE(SUM(wh.watch_duration), 0) as total_seconds,
      ROUND(COALESCE(SUM(wh.watch_duration), 0) / 3600.0, 1) as total_hours,
      MAX(wh.watched_at) as last_active
    FROM users u
    LEFT JOIN watch_history wh ON u.id = wh.user_id
    GROUP BY u.id
    ORDER BY total_hours DESC
  `).all();
  res.json(activity);
});

app.post('/api/admin/watch-history', requireAdmin, (req, res) => {
  const { user_id, lesson_id, watch_duration, last_position, completed } = req.body;
  db.prepare(`
    INSERT INTO watch_history (user_id, lesson_id, watch_duration, last_position, completed)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(user_id, lesson_id) DO UPDATE SET
      watch_duration = MAX(watch_duration, ?),
      last_position = ?,
      completed = ?,
      watched_at = CURRENT_TIMESTAMP
  `).run(user_id, lesson_id, watch_duration || 0, last_position || 0, completed || 0,
    watch_duration || 0, last_position || 0, completed || 0);
  res.json({ success: true });
});

// ─── Admin: Thumbnails ───
app.get('/api/admin/thumbnails', requireAdmin, (req, res) => {
  const thumbs = db.prepare(`
    SELECT vt.*, l.title as lesson_title
    FROM video_thumbnails vt
    JOIN lessons l ON vt.lesson_id = l.id
    ORDER BY vt.created_at DESC
  `).all();
  res.json(thumbs);
});

app.post('/api/admin/thumbnails', requireAdmin, (req, res) => {
  const { lesson_id, thumbnail_url } = req.body;
  if (!lesson_id || !thumbnail_url) {
    return res.status(400).json({ error: 'Required fields missing' });
  }
  const result = db.prepare(
    'INSERT INTO video_thumbnails (lesson_id, thumbnail_url) VALUES (?, ?)'
  ).run(lesson_id, thumbnail_url);
  res.json({ id: result.lastInsertRowid, lesson_id, thumbnail_url });
});

app.delete('/api/admin/thumbnails/:id', requireAdmin, (req, res) => {
  db.prepare('DELETE FROM video_thumbnails WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ─── Admin: Subjects & Lessons Management ───
app.post('/api/admin/subjects', requireAdmin, (req, res) => {
  const { level_id, name, slug, icon, color, thumbnail_url } = req.body;
  if (!level_id || !name || !slug) {
    return res.status(400).json({ error: 'Required fields missing' });
  }
  try {
    const result = db.prepare(
      'INSERT INTO subjects (level_id, name, slug, icon, color, thumbnail_url, lesson_count) VALUES (?, ?, ?, ?, ?, ?, 0)'
    ).run(level_id, name, slug, icon || '📚', color || '#185FA5', thumbnail_url || '');
    res.json({ id: result.lastInsertRowid, name, slug, icon, color, thumbnail_url, lesson_count: 0 });
  } catch (e) {
    if (e.message.includes('UNIQUE')) {
      return res.status(409).json({ error: 'Subject already exists' });
    }
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/admin/subjects/:id', requireAdmin, (req, res) => {
  const { name, icon, color, thumbnail_url } = req.body;
  const subject = db.prepare('SELECT * FROM subjects WHERE id = ?').get(req.params.id);
  if (!subject) return res.status(404).json({ error: 'Subject not found' });

  db.prepare('UPDATE subjects SET name = ?, icon = ?, color = ?, thumbnail_url = ? WHERE id = ?')
    .run(name || subject.name, icon || subject.icon, color || subject.color, thumbnail_url !== undefined ? thumbnail_url : subject.thumbnail_url, req.params.id);
  res.json({ success: true });
});

// ─── Admin: Chapters (Modules/Units) ───
app.post('/api/admin/chapters', requireAdmin, (req, res) => {
  const { subject_id, title } = req.body;
  if (!subject_id || !title) {
    return res.status(400).json({ error: 'Required fields missing' });
  }
  const maxOrder = db.prepare('SELECT MAX(sort_order) as max_order FROM chapters WHERE subject_id = ?').get(subject_id);
  const sortOrder = (maxOrder?.max_order || 0) + 1;
  const result = db.prepare('INSERT INTO chapters (subject_id, title, sort_order) VALUES (?, ?, ?)')
    .run(subject_id, title, sortOrder);
  res.json({ id: result.lastInsertRowid, subject_id, title, sort_order: sortOrder, lesson_count: 0 });
});

app.put('/api/admin/chapters/:id', requireAdmin, (req, res) => {
  const { title } = req.body;
  const chapter = db.prepare('SELECT * FROM chapters WHERE id = ?').get(req.params.id);
  if (!chapter) return res.status(404).json({ error: 'Chapter not found' });
  db.prepare('UPDATE chapters SET title = ? WHERE id = ?').run(title || chapter.title, req.params.id);
  res.json({ success: true });
});

app.delete('/api/admin/chapters/:id', requireAdmin, (req, res) => {
  const chapter = db.prepare('SELECT subject_id FROM chapters WHERE id = ?').get(req.params.id);
  if (!chapter) return res.status(404).json({ error: 'Chapter not found' });

  db.prepare('DELETE FROM watch_history WHERE lesson_id IN (SELECT id FROM lessons WHERE chapter_id = ?)').run(req.params.id);
  db.prepare('DELETE FROM video_thumbnails WHERE lesson_id IN (SELECT id FROM lessons WHERE chapter_id = ?)').run(req.params.id);
  db.prepare('DELETE FROM attachments WHERE lesson_id IN (SELECT id FROM lessons WHERE chapter_id = ?)').run(req.params.id);
  db.prepare('DELETE FROM lessons WHERE chapter_id = ?').run(req.params.id);
  db.prepare('DELETE FROM chapters WHERE id = ?').run(req.params.id);

  db.prepare('UPDATE subjects SET lesson_count = (SELECT COUNT(*) FROM lessons l JOIN chapters ch ON l.chapter_id = ch.id WHERE ch.subject_id = ?) WHERE id = ?')
    .run(chapter.subject_id, chapter.subject_id);

  res.json({ success: true });
});

// Endpoint to get subject tree with chapters and lessons for admin
app.get('/api/admin/subjects/:id/tree', requireAdmin, (req, res) => {
  const subjectId = req.params.id;
  const chapters = db.prepare('SELECT * FROM chapters WHERE subject_id = ? ORDER BY sort_order').all(subjectId);
  const tree = chapters.map(ch => {
    const lessons = db.prepare('SELECT * FROM lessons WHERE chapter_id = ? ORDER BY sort_order').all(ch.id);
    return { ...ch, lessons };
  });
  res.json(tree);
});

app.post('/api/admin/lessons', requireAdmin, (req, res) => {
  const { chapter_id, title, description, video_url, video_duration, tags, thumbnail_url, summary_url, exercise_url } = req.body;
  if (!chapter_id || !title) {
    return res.status(400).json({ error: 'Required fields missing' });
  }
  const maxOrder = db.prepare('SELECT MAX(sort_order) as max_order FROM lessons WHERE chapter_id = ?').get(chapter_id);
  const sortOrder = (maxOrder?.max_order || 0) + 1;

  const result = db.prepare(
    'INSERT INTO lessons (chapter_id, title, description, video_url, video_duration, tags, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).run(chapter_id, title, description || '', video_url || '', video_duration || '', tags || '', sortOrder);

  const lessonId = result.lastInsertRowid;

  if (thumbnail_url) {
    db.prepare('INSERT INTO video_thumbnails (lesson_id, thumbnail_url) VALUES (?, ?)').run(lessonId, thumbnail_url);
  }

  if (summary_url) {
    db.prepare("INSERT INTO attachments (lesson_id, type, title, file_url) VALUES (?, 'summary', ?, ?)")
      .run(lessonId, 'Résumé de la leçon', summary_url);
  }
  if (exercise_url) {
    db.prepare("INSERT INTO attachments (lesson_id, type, title, file_url) VALUES (?, 'exercise', ?, ?)")
      .run(lessonId, 'Exercice', exercise_url);
  }

  // Update subject lesson count
  const chapter = db.prepare('SELECT subject_id FROM chapters WHERE id = ?').get(chapter_id);
  if (chapter) {
    db.prepare('UPDATE subjects SET lesson_count = (SELECT COUNT(*) FROM lessons l JOIN chapters ch ON l.chapter_id = ch.id WHERE ch.subject_id = ?) WHERE id = ?')
      .run(chapter.subject_id, chapter.subject_id);
  }

  res.json({ id: lessonId, title, video_url, thumbnail_url });
});

app.put('/api/admin/lessons/:id', requireAdmin, (req, res) => {
  const { title, description, video_url, video_duration, tags, thumbnail_url } = req.body;
  const lesson = db.prepare('SELECT * FROM lessons WHERE id = ?').get(req.params.id);
  if (!lesson) return res.status(404).json({ error: 'Lesson not found' });

  db.prepare('UPDATE lessons SET title = ?, description = ?, video_url = ?, video_duration = ?, tags = ? WHERE id = ?')
    .run(title || lesson.title, description || lesson.description, video_url || lesson.video_url,
      video_duration || lesson.video_duration, tags || lesson.tags, req.params.id);

  if (thumbnail_url) {
    db.prepare('DELETE FROM video_thumbnails WHERE lesson_id = ?').run(req.params.id);
    db.prepare('INSERT INTO video_thumbnails (lesson_id, thumbnail_url) VALUES (?, ?)').run(req.params.id, thumbnail_url);
  }

  res.json({ success: true });
});

app.delete('/api/admin/lessons/:id', requireAdmin, (req, res) => {
  const lesson = db.prepare('SELECT chapter_id FROM lessons WHERE id = ?').get(req.params.id);
  db.prepare('DELETE FROM watch_history WHERE lesson_id = ?').run(req.params.id);
  db.prepare('DELETE FROM video_thumbnails WHERE lesson_id = ?').run(req.params.id);
  db.prepare('DELETE FROM attachments WHERE lesson_id = ?').run(req.params.id);
  db.prepare('DELETE FROM lessons WHERE id = ?').run(req.params.id);

  if (lesson) {
    const chapter = db.prepare('SELECT subject_id FROM chapters WHERE id = ?').get(lesson.chapter_id);
    if (chapter) {
      db.prepare('UPDATE subjects SET lesson_count = (SELECT COUNT(*) FROM lessons l JOIN chapters ch ON l.chapter_id = ch.id WHERE ch.subject_id = ?) WHERE id = ?')
        .run(chapter.subject_id, chapter.subject_id);
    }
  }
  res.json({ success: true });
});

// ─── Auth (simplified) ───
app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  try {
    const result = db.prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)').run(name, email, hashPassword(password));
    res.json({ id: result.lastInsertRowid, name, email });
  } catch (e) {
    if (e.message.includes('UNIQUE')) {
      return res.status(409).json({ error: "Cet e-mail existe déjà" });
    }
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT id, name, email, password, ip_address FROM users WHERE email = ?').get(email);
  if (!user) return res.status(401).json({ error: 'Identifiants incorrects' });

  // Verify scrypt hash; fall back to plaintext match for legacy rows.
  let valid = false;
  try {
    valid = verifyPassword(password || '', user.password);
  } catch (e) {
    valid = false;
  }
  const legacyPlaintext = password && user.password === password;
  if (!valid) {
    if (!legacyPlaintext) return res.status(401).json({ error: 'Identifiants incorrects' });
    // Legacy plaintext match: migrate to a scrypt hash on successful login.
    db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashPassword(password), user.id);
  }

  const clientIP = getClientIP(req);

  // One account = one person (locked to the IP that first logged in)
  if (user.ip_address) {
    if (user.ip_address !== clientIP) {
      return res.status(403).json({ error: 'Ce compte est lié à un seul appareil/adresse IP. Contactez l\'administration.' });
    }
  }

  // Bind account to this IP on first login; keep it locked afterwards.
  // null client IP means undetermined: leave ip_address unbound.
  db.prepare('UPDATE users SET ip_address = CASE WHEN ip_address IS NULL THEN ? ELSE ip_address END, last_login_ip = ? WHERE id = ?')
    .run(clientIP, clientIP, user.id);

  // Attach the student's level so the app can restrict which courses they see.
  const student = db.prepare('SELECT level FROM students WHERE email = ?').get(user.email);
  const levelSlug = student ? mapStudentLevel(student.level) : null;

  res.json({ id: user.id, name: user.name, email: user.email, level_slug: levelSlug });
});

// ─── Progress ───
app.get('/api/progress/:userId', (req, res) => {
  const progress = db.prepare('SELECT * FROM progress WHERE user_id = ?').all(req.params.userId);
  res.json(progress);
});

app.post('/api/progress', (req, res) => {
  const { user_id, lesson_id, completed } = req.body;
  db.prepare(`
    INSERT INTO progress (user_id, lesson_id, completed, completed_at)
    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(user_id, lesson_id) DO UPDATE SET completed = ?, completed_at = CURRENT_TIMESTAMP
  `).run(user_id, lesson_id, completed, completed);
  res.json({ success: true });
});

// ─── Global error handler ───
app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: 'Fichier trop volumineux' });
  }
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: 'Erreur lors du téléversement du fichier' });
  }
  const status = err.status || 500;
  return res.status(status).json({ error: status === 500 ? 'Erreur interne du serveur' : (err.message || 'Erreur') });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
