import db from './db.js';

const insertLevel = db.prepare('INSERT OR IGNORE INTO levels (name, slug, icon, description) VALUES (?, ?, ?, ?)');
const insertSubject = db.prepare('INSERT OR IGNORE INTO subjects (level_id, name, slug, icon, color, lesson_count) VALUES (?, ?, ?, ?, ?, ?)');
const insertChapter = db.prepare('INSERT OR IGNORE INTO chapters (subject_id, title, sort_order) VALUES (?, ?, ?)');
const insertLesson = db.prepare('INSERT OR IGNORE INTO lessons (chapter_id, title, description, video_url, video_duration, tags, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)');
const insertAttachment = db.prepare('INSERT OR IGNORE INTO attachments (lesson_id, type, title, file_url) VALUES (?, ?, ?, ?)');
const insertTeacher = db.prepare('INSERT OR IGNORE INTO teachers (name, initials, role, experience, bio, gradient_class) VALUES (?, ?, ?, ?, ?, ?)');
const insertStudent = db.prepare('INSERT OR IGNORE INTO students (name, email, level, paid_on, next_due, status) VALUES (?, ?, ?, ?, ?, ?)');
const insertMedia = db.prepare('INSERT OR IGNORE INTO media_files (name, type, category, size, file_url) VALUES (?, ?, ?, ?, ?)');

const seed = () => {
  db.exec('BEGIN IMMEDIATE');
  try {
    const levelCount = db.prepare('SELECT COUNT(*) as count FROM levels').get().count;
    if (levelCount > 0) {
      db.exec('COMMIT');
      console.log('✅ Database already seeded, skipped');
      return;
    }
    // Levels
    insertLevel.run('Première année', 'bac1', '📘', '6 matières disponibles · Économie générale, Comptabilité, Statistiques');
    insertLevel.run('Deuxième année', 'bac2', '🎓', '8 matières disponibles · Économie générale, Gestion, Comptabilité');

  // Subjects - Bac 1
  insertSubject.run(1, 'Économie générale', 'economie-generale', '📊', '#639922', 12);
  insertSubject.run(1, 'Comptabilité générale', 'comptabilite', '🧮', '#534AB7', 9);
  insertSubject.run(1, 'Statistiques appliquées', 'statistique', '📈', '#185FA5', 8);

  // Subjects - Bac 2
  insertSubject.run(2, 'Économie générale et Statistiques', 'economie-stat', '📊', '#639922', 14);
  insertSubject.run(2, 'Gestion', 'management', '🏢', '#D97706', 11);
  insertSubject.run(2, 'Comptabilité générale', 'comptabilite-bac2', '🧮', '#534AB7', 10);

  // Chapters - Economie Generale (subject 1)
  insertChapter.run(1, 'Chapitre 1 : Le marché et la concurrence', 1);
  insertChapter.run(1, 'Chapitre 2 : Le circuit économique', 2);

  // Lessons - Chapter 1
  insertLesson.run(1, 'Le concept du marché', 'Définition du marché et de ses caractéristiques fondamentales', '/videos/marche.mp4', '10:30', '#définition,#caractéristiques', 1);
  insertLesson.run(1, 'Les types de marchés', 'Classification des marchés selon la nature et l\'étendue', '/videos/types-marche.mp4', '12:45', '#définition,#loi,#éléments', 2);
  insertLesson.run(1, 'L\'offre et la demande', 'Les lois de l\'offre et de la demande et leur effet sur le prix', '/videos/offre-demande.mp4', '15:20', '#offre,#demande', 3);
  insertLesson.run(1, 'L\'équilibre du marché', 'Comment le prix se détermine dans un marché libre', '/videos/equilibre.mp4', '11:10', '#équilibre,#prix', 4);

  // Lessons - Chapter 2
  insertLesson.run(2, 'Le cycle économique', 'Définition du cycle économique et de ses phases', '/videos/cycle.mp4', '14:00', '#cycle,#phases', 1);
  insertLesson.run(2, 'Les crises économiques', 'Les causes et les types des crises économiques', '/videos/crises.mp4', '13:30', '#crises,#causes', 2);

  // Attachments
  insertAttachment.run(1, 'summary', 'Résumé de la leçon PDF', '/files/summary-marche.pdf');
  insertAttachment.run(1, 'exercise', 'Exercice pratique PDF', '/files/exercise-marche.pdf');
  insertAttachment.run(2, 'summary', 'Résumé de la leçon PDF', '/files/summary-types.pdf');
  insertAttachment.run(2, 'exercise', 'Exercice pratique PDF', '/files/exercise-types.pdf');
  insertAttachment.run(3, 'summary', 'Résumé de la leçon PDF', '/files/summary-offre.pdf');
  insertAttachment.run(3, 'exercise', 'Exercice pratique PDF', '/files/exercise-offre.pdf');

  // Teachers
  insertTeacher.run('Saïd Alaoui', 'S.A', 'Professeur d\'économie générale', '15 ans d\'expérience', 'Enseignant de l\'économie et des statistiques pour le baccalauréat, il a participé à la correction de l\'examen national pendant plusieurs sessions et s\'efforce de simplifier les concepts théoriques à travers des exemples de la réalité marocaine.', 't1');
  insertTeacher.run('Nadia Benali', 'N.B', 'Professeure de comptabilité et de gestion', '10 ans d\'expérience', 'Spécialiste de la comptabilité générale et de la gestion, elle met l\'accent dans ses explications sur les exercices pratiques et les techniques de réponse méthodique à l\'examen.', 't2');

  // Students
  insertStudent.run('Amine Saidi', 'amine@gmail.com', '2ème Bac', '2026-09-01', '2026-10-01', 'active');
  insertStudent.run('Sara Bennis', 'sara@gmail.com', '1ère Bac', '2026-08-28', '2026-09-27', 'overdue');
  insertStudent.run('Youssef El Merabet', 'youssef@gmail.com', '2ème Bac', '2026-08-22', '2026-09-21', 'overdue');
  insertStudent.run('Mohamed El Idrissi', 'med@gmail.com', '2ème Bac', '2026-09-05', '2026-10-05', 'active');
  insertStudent.run('Khadija El Amrani', 'khadija@gmail.com', '2ème Bac', '2026-08-30', '2026-09-29', 'overdue');
  insertStudent.run('Ilyass El Tazi', 'ilyass@gmail.com', '1ère Bac', '2026-09-02', '2026-10-02', 'active');
  insertStudent.run('Meriem Benani', 'meriem@gmail.com', '2ème Bac', '2026-08-19', '2026-09-18', 'overdue');
  insertStudent.run('Omar El Fassi', 'omar@gmail.com', '1ère Bac', '2026-09-06', '2026-10-06', 'active');

  // Media Files
  insertMedia.run('resume_marché.pdf', 'pdf', 'Résumés', '1.2 MB', '/files/resume_marche.pdf');
  insertMedia.run('exercice_marché.pdf', 'pdf', 'Exercices', '840 KB', '/files/exercice_marche.pdf');
  insertMedia.run('correction_marché.pdf', 'pdf', 'Corrections', '1.1 MB', '/files/correction_marche.pdf');
  insertMedia.run('lesson_marche.mp4', 'video', 'Vidéos', '128 MB', '/files/lesson_marche.mp4');
  insertMedia.run('resume_echanges.pdf', 'pdf', 'Résumés', '980 KB', '/files/resume_echanges.pdf');
  insertMedia.run('exam_blanc_1.pdf', 'pdf', 'Examens', '1.5 MB', '/files/exam_blanc_1.pdf');
  insertMedia.run('correction_organisation.pdf', 'pdf', 'Corrections', '900 KB', '/files/correction_organisation.pdf');
  insertMedia.run('cours_gestion.mp4', 'video', 'Vidéos', '95 MB', '/files/cours_gestion.mp4');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  db.exec('COMMIT');
};

seed();

console.log('✅ Database seeded successfully!');
