import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const db = new DatabaseSync(join(__dirname, 'platform.db'));

db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS levels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    icon TEXT,
    description TEXT
  );

  CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    slug TEXT NOT NULL,
    icon TEXT,
    color TEXT,
    thumbnail_url TEXT,
    lesson_count INTEGER DEFAULT 0,
    FOREIGN KEY (level_id) REFERENCES levels(id)
  );

  CREATE TABLE IF NOT EXISTS chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    sort_order INTEGER DEFAULT 0,
    FOREIGN KEY (subject_id) REFERENCES subjects(id)
  );

  CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chapter_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    video_url TEXT,
    video_duration TEXT,
    tags TEXT,
    sort_order INTEGER DEFAULT 0,
    FOREIGN KEY (chapter_id) REFERENCES chapters(id)
  );

  CREATE TABLE IF NOT EXISTS attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id INTEGER NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('summary', 'exercise')),
    title TEXT NOT NULL,
    file_url TEXT,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id)
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    lesson_id INTEGER NOT NULL,
    completed INTEGER DEFAULT 0,
    completed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    UNIQUE(user_id, lesson_id)
  );

  CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    initials TEXT NOT NULL,
    role TEXT NOT NULL,
    experience TEXT,
    bio TEXT,
    gradient_class TEXT
  );

  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    level TEXT NOT NULL,
    auto_renew INTEGER DEFAULT 1,
    paid_on TEXT,
    next_due TEXT,
    status TEXT DEFAULT 'active' CHECK(status IN ('active', 'overdue', 'disabled')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS media_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('pdf', 'video', 'image')),
    category TEXT NOT NULL,
    size TEXT,
    file_url TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS watch_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    lesson_id INTEGER NOT NULL,
    watch_duration INTEGER DEFAULT 0,
    last_position INTEGER DEFAULT 0,
    completed INTEGER DEFAULT 0,
    watched_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id),
    UNIQUE(user_id, lesson_id)
  );

  CREATE TABLE IF NOT EXISTS video_thumbnails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id INTEGER NOT NULL,
    thumbnail_url TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lesson_id) REFERENCES lessons(id)
  );

  CREATE TABLE IF NOT EXISTS admin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

try { db.exec("ALTER TABLE subjects ADD COLUMN thumbnail_url TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE users ADD COLUMN ip_address TEXT"); } catch(e) {}
try { db.exec("ALTER TABLE users ADD COLUMN last_login_ip TEXT"); } catch(e) {}

// ─── Password hashing (scrypt) ───
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const test = crypto.scryptSync(password, salt, 64);
  return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), test);
}

// ─── Seed default admin ───
// Set ADMIN_PASSWORD env var to customize; defaults to 'HpqyQluYjg4qWxpV'
function seedAdmin() {
  const exists = db.prepare('SELECT COUNT(*) as count FROM admin').get();
  if (exists.count === 0) {
    const username = process.env.ADMIN_USERNAME || 'admin';
    const password = process.env.ADMIN_PASSWORD || 'HpqyQluYjg4qWxpV';
    db.prepare('INSERT INTO admin (username, password_hash) VALUES (?, ?)').run(username, hashPassword(password));
    console.log('============================================================');
    console.log(`  Admin created. Username: ${username}`);
    console.log(`  Password: ${password}`);
    console.log('  (change via ADMIN_PASSWORD env var or /api/admin/change-password)');
    console.log('============================================================');
  }
}
seedAdmin();

// ─── Auto-seed content on first run (empty DB) ───
function seedContent() {
  const ins = {
    level:    db.prepare('INSERT OR IGNORE INTO levels (name, slug, icon, description) VALUES (?, ?, ?, ?)'),
    subject:  db.prepare('INSERT OR IGNORE INTO subjects (level_id, name, slug, icon, color, thumbnail_url, lesson_count) VALUES (?, ?, ?, ?, ?, ?, ?)'),
    chapter:  db.prepare('INSERT OR IGNORE INTO chapters (subject_id, title, sort_order) VALUES (?, ?, ?)'),
    lesson:   db.prepare('INSERT OR IGNORE INTO lessons (chapter_id, title, description, video_url, video_duration, tags, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)'),
    attach:   db.prepare('INSERT OR IGNORE INTO attachments (lesson_id, type, title, file_url) VALUES (?, ?, ?, ?)'),
    teacher:  db.prepare('INSERT OR IGNORE INTO teachers (name, initials, role, experience, bio, gradient_class) VALUES (?, ?, ?, ?, ?, ?)'),
    student:  db.prepare('INSERT OR IGNORE INTO students (name, email, level, paid_on, next_due, status) VALUES (?, ?, ?, ?, ?, ?)'),
  };

  // BEGIN IMMEDIATE grabs the write lock so two simultaneous starts cannot
  // both observe an empty DB and double-seed.
  db.exec('BEGIN IMMEDIATE');
  try {
    const levelCount = db.prepare('SELECT COUNT(*) as count FROM levels').get().count;
    if (levelCount > 0) {
      db.exec('COMMIT'); // already seeded
      return;
    }
    // Levels
    ins.level.run('Première année', 'bac1', '📘', 'Économie générale, Comptabilité, Statistiques');
    ins.level.run('Deuxième année', 'bac2', '🎓', 'Économie générale, Gestion, Comptabilité');

    // Subjects — Bac 1
    ins.subject.run(1, 'Économie générale', 'economie-generale', '📊', '#639922', null, 12);
    ins.subject.run(1, 'Comptabilité générale', 'comptabilite', '🧮', '#534AB7', null, 9);
    ins.subject.run(1, 'Statistiques appliquées', 'statistique', '📈', '#185FA5', null, 8);

    // Subjects — Bac 2
    ins.subject.run(2, 'Économie générale et Statistiques', 'economie-stat', '📊', '#639922', null, 14);
    ins.subject.run(2, 'Gestion', 'management', '🏢', '#D97706', null, 11);
    ins.subject.run(2, 'Comptabilité générale', 'comptabilite-bac2', '🧮', '#534AB7', null, 10);

    // Chapters — Économie générale (subject 1)
    ins.chapter.run(1, 'Chapitre 1 : Le marché et la concurrence', 1);
    ins.chapter.run(1, 'Chapitre 2 : Le circuit économique', 2);

    // Lessons — Chapter 1
    ins.lesson.run(1, 'Le concept du marché', 'Définition du marché et de ses caractéristiques fondamentales', '', '10:30', '#définition,#caractéristiques', 1);
    ins.lesson.run(1, 'Les types de marchés', 'Classification des marchés selon la nature et l\'étendue', '', '12:45', '#définition,#loi,#éléments', 2);
    ins.lesson.run(1, 'L\'offre et la demande', 'Les lois de l\'offre et de la demande et leur effet sur le prix', '', '15:20', '#offre,#demande', 3);
    ins.lesson.run(1, 'L\'équilibre du marché', 'Comment le prix se détermine dans un marché libre', '', '11:10', '#équilibre,#prix', 4);

    // Lessons — Chapter 2
    ins.lesson.run(2, 'Le cycle économique', 'Définition du cycle économique et de ses phases', '', '14:00', '#cycle,#phases', 1);
    ins.lesson.run(2, 'Les crises économiques', 'Les causes et les types des crises économiques', '', '13:30', '#crises,#causes', 2);

    // Teachers
    ins.teacher.run('Saïd Alaoui', 'S.A', 'Professeur d\'économie générale', '15 ans d\'expérience', 'Enseignant simplifiant les concepts théoriques à travers des exemples de la réalité marocaine.', 't1');
    ins.teacher.run('Nadia Benali', 'N.B', 'Professeure de comptabilité et de gestion', '10 ans d\'expérience', 'Spécialiste de la comptabilité générale, elle met l\'accent sur les exercices pratiques.', 't2');

    // Demo students
    ins.student.run('Amine Saidi', 'amine@gmail.com', '2ème Bac', '2026-09-01', '2026-10-01', 'active');
    ins.student.run('Sara Bennis', 'sara@gmail.com', '1ère Bac', '2026-08-28', '2026-09-27', 'overdue');
    ins.student.run('Youssef El Merabet', 'youssef@gmail.com', '2ème Bac', '2026-08-22', '2026-09-21', 'overdue');
    ins.student.run('Mohamed El Idrissi', 'med@gmail.com', '2ème Bac', '2026-09-05', '2026-10-05', 'active');
    ins.student.run('Khadija El Amrani', 'khadija@gmail.com', '2ème Bac', '2026-08-30', '2026-09-29', 'overdue');
    ins.student.run('Ilyass El Tazi', 'ilyass@gmail.com', '1ère Bac', '2026-09-02', '2026-10-02', 'active');
    ins.student.run('Meriem Benani', 'meriem@gmail.com', '2ème Bac', '2026-08-19', '2026-09-18', 'overdue');
    ins.student.run('Omar El Fassi', 'omar@gmail.com', '1ère Bac', '2026-09-06', '2026-10-06', 'active');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  db.exec('COMMIT');

  console.log('✅ Content seeded: 2 levels, 6 subjects, 2 chapters, 6 lessons, 2 teachers, 8 demo students');
}
seedContent();

export default db;
