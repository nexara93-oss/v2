const API_BASE = '/api';

function adminHeaders(extra = {}) {
  const token = localStorage.getItem('ae_admin_token');
  const headers = { ...extra };
  if (token) headers['x-admin-token'] = token;
  return headers;
}

async function fetchJSON(url) {
  const res = await fetch(`${API_BASE}${url}`, { headers: adminHeaders() });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export async function getHeroImages() {
  return fetchJSON('/hero/images');
}

export async function adminLogin(username, password) {
  const res = await fetch(`${API_BASE}/admin/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  return res.json();
}

export async function adminLogout() {
  const token = localStorage.getItem('ae_admin_token');
  await fetch(`${API_BASE}/admin/auth/logout`, {
    method: 'POST',
    headers: adminHeaders(),
    body: JSON.stringify({ token }),
  });
}

export async function adminCheckValid() {
  try {
    const res = await fetch(`${API_BASE}/admin/auth/check`, { headers: adminHeaders() });
    const data = await res.json();
    return !!data.valid;
  } catch {
    return false;
  }
}

export async function getLevels() {
  return fetchJSON('/levels');
}

export async function getSubjects(levelSlug) {
  const q = levelSlug ? `?level_slug=${levelSlug}` : '';
  return fetchJSON(`/subjects${q}`);
}

export async function getSubject(slug) {
  return fetchJSON(`/subjects/${slug}`);
}

export async function getChapters(subjectSlug) {
  return fetchJSON(`/subjects/${subjectSlug}/chapters`);
}

export async function getLessons(chapterId) {
  return fetchJSON(`/chapters/${chapterId}/lessons`);
}

export async function getSubjectLessons(subjectSlug) {
  return fetchJSON(`/subjects/${subjectSlug}/lessons`);
}

export async function getLesson(id) {
  return fetchJSON(`/lessons/${id}`);
}

export async function getTeachers() {
  return fetchJSON('/teachers');
}

export async function loginUser(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  return res.json();
}

export async function registerUser(name, email, password) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, password }),
  });
  return res.json();
}

export async function getProgress(userId) {
  return fetchJSON(`/progress/${userId}`);
}

export async function updateProgress(userId, lessonId, completed) {
  const res = await fetch(`${API_BASE}/progress`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ user_id: userId, lesson_id: lessonId, completed }),
  });
  return res.json();
}

// ─── Admin: Levels ───
export async function getAdminLevels() {
  return fetchJSON('/admin/levels');
}

export async function addLevel(data) {
  const res = await fetch(`${API_BASE}/admin/levels`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateLevel(id, data) {
  const res = await fetch(`${API_BASE}/admin/levels/${id}`, {
    method: 'PUT',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteLevel(id) {
  const res = await fetch(`${API_BASE}/admin/levels/${id}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  });
  return res.json();
}

// ─── Admin API ───
export async function getAdminStats() {
  return fetchJSON('/admin/stats');
}

export async function getAdminStudents() {
  return fetchJSON('/admin/students');
}

export async function addStudent(name, email, level) {
  const res = await fetch(`${API_BASE}/admin/students`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ name, email, level }),
  });
  return res.json();
}

export async function updateStudent(id, data) {
  const res = await fetch(`${API_BASE}/admin/students/${id}`, {
    method: 'PUT',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteStudent(id) {
  const res = await fetch(`${API_BASE}/admin/students/${id}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  });
  return res.json();
}

export async function resetStudentIP(id) {
  const res = await fetch(`${API_BASE}/admin/students/${id}/reset-ip`, {
    method: 'POST',
    headers: adminHeaders(),
  });
  return res.json();
}

export async function getAdminMedia() {
  return fetchJSON('/admin/media');
}

export async function addMedia(data) {
  const res = await fetch(`${API_BASE}/admin/media`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteMedia(id) {
  const res = await fetch(`${API_BASE}/admin/media/${id}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  });
  return res.json();
}

// ─── Admin: Watch History ───
export async function getWatchHistory() {
  return fetchJSON('/admin/watch-history');
}

export async function getUserActivity() {
  return fetchJSON('/admin/user-activity');
}

export async function addWatchHistory(data) {
  const res = await fetch(`${API_BASE}/admin/watch-history`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

// ─── Admin: Thumbnails ───
export async function getThumbnails() {
  return fetchJSON('/admin/thumbnails');
}

export async function addThumbnail(lessonId, thumbnailUrl) {
  const res = await fetch(`${API_BASE}/admin/thumbnails`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ lesson_id: lessonId, thumbnail_url: thumbnailUrl }),
  });
  return res.json();
}

export async function deleteThumbnail(id) {
  const res = await fetch(`${API_BASE}/admin/thumbnails/${id}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  });
  return res.json();
}

// ─── Admin: Upload ───
export async function uploadFile(file) {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${API_BASE}/admin/upload`, {
    method: 'POST',
    headers: adminHeaders(),
    body: formData,
  });
  return res.json();
}

export async function uploadVideo(file) {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${API_BASE}/admin/upload/video`, {
    method: 'POST',
    headers: adminHeaders(),
    body: formData,
  });
  return res.json();
}

export async function uploadPdf(file) {
  const formData = new FormData();
  formData.append('file', file);
  const res = await fetch(`${API_BASE}/admin/upload/pdf`, {
    method: 'POST',
    headers: adminHeaders(),
    body: formData,
  });
  return res.json();
}

// ─── Admin: Subjects & Lessons ───
export async function addSubject(data) {
  const res = await fetch(`${API_BASE}/admin/subjects`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateSubject(id, data) {
  const res = await fetch(`${API_BASE}/admin/subjects/${id}`, {
    method: 'PUT',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

// ─── Admin: Chapters (Modules/Units) ───
export async function getSubjectTree(subjectId) {
  const res = await fetch(`${API_BASE}/admin/subjects/${subjectId}/tree`, { headers: adminHeaders() });
  return res.json();
}

export async function addChapter(subjectId, title) {
  const res = await fetch(`${API_BASE}/admin/chapters`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ subject_id: subjectId, title }),
  });
  return res.json();
}

export async function updateChapter(id, title) {
  const res = await fetch(`${API_BASE}/admin/chapters/${id}`, {
    method: 'PUT',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ title }),
  });
  return res.json();
}

export async function deleteChapter(id) {
  const res = await fetch(`${API_BASE}/admin/chapters/${id}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  });
  return res.json();
}

export async function addLesson(data) {
  const res = await fetch(`${API_BASE}/admin/lessons`, {
    method: 'POST',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function updateLesson(id, data) {
  const res = await fetch(`${API_BASE}/admin/lessons/${id}`, {
    method: 'PUT',
    headers: adminHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify(data),
  });
  return res.json();
}

export async function deleteLesson(id) {
  const res = await fetch(`${API_BASE}/admin/lessons/${id}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  });
  return res.json();
}
