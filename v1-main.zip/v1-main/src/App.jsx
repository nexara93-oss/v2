import { BrowserRouter, Routes, Route, useLocation, Navigate, Link } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { useEffect, useState } from 'react';
import { adminCheckValid } from './api';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Courses from './pages/Courses';
import SubjectPage from './pages/SubjectPage';
import LessonPage from './pages/LessonPage';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Admin from './pages/admin/Admin';
import AdminLogin from './pages/admin/AdminLogin';

function AdminGate() {
  const [checked, setChecked] = useState(false);
  const [valid, setValid] = useState(false);

  useEffect(() => {
    adminCheckValid().then((ok) => {
      setValid(ok);
      setChecked(true);
    });
  }, []);

  if (!checked) return <div className="container loading">Vérification...</div>;
  if (!valid) return <Navigate to="/admin/login" replace />;
  return <Admin />;
}

function NotFoundMain() {
  return (
    <div className="container page-hero">
      <h1>Page introuvable</h1>
      <p>La page que vous recherchez n'existe pas.</p>
      <Link to="/">Retour à l'accueil</Link>
    </div>
  );
}

function AppContent() {
  const location = useLocation();
  const isAdminPanel = location.pathname.startsWith('/admin') && location.pathname !== '/admin/login';

  useEffect(() => {
    const path = location.pathname;
    let title = 'Plateforme Économie Éducative';
    if (path === '/') title = 'Accueil | Plateforme Économie Éducative';
    else if (path === '/courses') title = 'Nos cours | Plateforme Économie Éducative';
    else if (path.startsWith('/subject/')) title = 'Matière | Plateforme Économie Éducative';
    else if (path.startsWith('/lesson/')) title = 'Leçon | Plateforme Économie Éducative';
    else if (path === '/login') title = 'Connexion | Plateforme Économie Éducative';
    else if (path === '/dashboard') title = 'Tableau de bord | Plateforme Économie Éducative';
    else if (path === '/admin/login') title = 'Administration | Plateforme Économie Éducative';
    else if (isAdminPanel) title = 'Administration | Plateforme Économie Éducative';
    document.title = title;
  }, [location.pathname, isAdminPanel]);

  return (
    <>
      {!isAdminPanel && <Header />}
      {!isAdminPanel && <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/subject/:slug" element={<SubjectPage />} />
          <Route path="/lesson/:id" element={<LessonPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="*" element={<NotFoundMain />} />
        </Routes>
      </main>}
      {isAdminPanel && <AdminGate />}
      {!isAdminPanel && <Footer />}
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </AuthProvider>
  );
}
