export default function Marquee() {
  const items = [
    '🎉 Offre de lancement : les deux premières leçons gratuites dans chaque matière — tous niveaux',
    '📚 Vidéo explicative + résumé PDF + exercice pratique dans chaque leçon',
    '✅ Plus de 1250 étudiants révisent avec nous maintenant',
  ];

  return (
    <div className="marquee-bar" aria-hidden="true">
      <div className="marquee-track">
        {[...items, ...items].map((item, i) => (
          <span key={i}>{item}</span>
        ))}
      </div>
    </div>
  );
}
