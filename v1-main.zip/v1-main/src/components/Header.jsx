import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path) => location.pathname === path;
  const isCoursesActive = location.pathname.startsWith('/courses') || location.pathname.startsWith('/subject') || location.pathname.startsWith('/lesson');

  return (
    <header className="site-header">
      <div className="container">
        <div className="header-left">
          {location.pathname !== '/dashboard' && (
            <Link to="/" className="logo">
              <img src="/logo.svg" alt="Économie Avec Ashraf" className="logo-img" />
            </Link>
          )}
        </div>

        <nav id="primary-nav" aria-label="Navigation principale" className={`nav-links ${menuOpen ? 'open' : ''}`}>
          <Link to="/" className={isActive('/') ? 'active' : ''} onClick={() => setMenuOpen(false)}>Accueil</Link>
          <Link to="/courses" className={isCoursesActive ? 'active' : ''} onClick={() => setMenuOpen(false)}>Nos cours</Link>
        </nav>

        <div className="header-actions">
          <button type="button" className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu" aria-expanded={menuOpen} aria-controls="primary-nav">☰</button>
          {user ? (
            <div className="user-menu">
              <Link to="/dashboard" className="btn btn-outline">{user.name}</Link>
              <button className="btn btn-ghost" onClick={logout}>Déconnexion</button>
            </div>
          ) : (
            <button type="button" className="btn btn-orange" onClick={() => navigate('/login')}>Se connecter</button>
          )}
        </div>
      </div>
    </header>
  );
}
