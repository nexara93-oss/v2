import { useState, useEffect, useCallback } from 'react';
import { getHeroImages } from '../api';

const defaults = [
  {
    image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1400&q=80',
    title: 'Votre plateforme complète pour apprendre',
    highlight: 'l\'économie',
    subtitle: 'Vidéos explicatives, résumés prêts et exercices pratiques pour le niveau du Baccalauréat',
  },
  {
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1400&q=80',
    title: 'Renforcez vos connaissances en',
    highlight: 'comptabilité et gestion',
    subtitle: 'Cours interactifs avec des professeurs expérimentés sur le terrain',
  },
  {
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1400&q=80',
    title: 'Avec ashraf',
    highlight: 'assurez votre réussite',
    subtitle: 'Plus de 1250 étudiants révisent avec nous — rejoignez-nous maintenant',
  },
];

export default function HeroSlider() {
  const [slides, setSlides] = useState(defaults);
  const [current, setCurrent] = useState(0);
  const [animDir, setAnimDir] = useState('next');

  useEffect(() => {
    let mounted = true;
    getHeroImages()
      .then((imgs) => {
        if (!mounted) return;
        if (imgs && imgs.length) {
          const custom = imgs.map((src, i) => {
            const d = defaults[i % defaults.length];
            return { ...d, image: src };
          });
          setSlides(custom);
        }
      })
      .catch(() => {});
    return () => { mounted = false; };
  }, []);

  const goTo = useCallback((index) => {
    setCurrent(prev => {
      setAnimDir(index > prev ? 'next' : 'prev');
      return index;
    });
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent(prev => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <section className="hero-slider">
      {slides.map((slide, i) => (
        <div
          key={i}
          className={`hero-slide ${i === current ? 'active' : ''}`}
          style={{ backgroundImage: `url(${slide.image})` }}
        >
          <div className="hero-overlay"></div>
        </div>
      ))}

      <div className="container hero-content">
        {slides.map((slide, i) => (
          <div key={i} className={`hero-text ${i === current ? 'active' : ''}`}>
            <h1>
              {slide.title} <em>{slide.highlight}</em>
            </h1>
            <p>{slide.subtitle}</p>
          </div>
        ))}
      </div>

      <div className="hero-dots">
        {slides.map((_, i) => (
          <button
            key={i}
            type="button"
            className={`hero-dot ${i === current ? 'active' : ''}`}
            onClick={() => goTo(i)}
            aria-label={`Slide ${i + 1}`}
            aria-current={i === current ? 'true' : undefined}
          />
        ))}
      </div>

      <div className="hero-progress">
        <div className="hero-progress-bar" key={current}></div>
      </div>
    </section>
  );
}