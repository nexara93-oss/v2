export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="socials">
          <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" aria-label="Instagram">Instagram</a>
        </div>
        <p>© 2026 Plateforme Économie Éducative. Tous droits réservés.</p>
      </div>
    </footer>
  );
}
