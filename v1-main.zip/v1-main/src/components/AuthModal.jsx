import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { loginUser } from '../api';

export default function AuthModal({ type, onClose }) {
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const user = await loginUser(form.email, form.password);
      if (user.error) {
        setError(user.error);
      } else {
        login(user);
        onClose();
      }
    } catch {
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`modal-overlay ${type ? 'open' : ''}`} onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h2>Bienvenue</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <div className="tabs">
          <button className="tab active">Connexion</button>
        </div>

        {error && <div className="error-msg">{error}</div>}

        <form onSubmit={handleSubmit} className="tab-panel active">
          <div className="field">
            <label>Adresse e-mail</label>
            <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="name@example.com" required />
          </div>
          <div className="field">
            <label>Mot de passe</label>
            <input type="password" name="password" value={form.password} onChange={handleChange} placeholder="••••••••" required />
          </div>
          <div className="field-row">
            <label><input type="checkbox" /> Se souvenir de moi</label>
            <a href="#">Mot de passe oublié ?</a>
          </div>
          <button type="submit" className="btn btn-orange btn-block" disabled={loading}>
            {loading ? 'Traitement...' : 'Se connecter'}
          </button>
          <div className="divider">ou se connecter avec</div>
          <div className="social-row">
            <button type="button" className="btn btn-ghost">Google</button>
            <button type="button" className="btn btn-ghost">Facebook</button>
          </div>
        </form>
      </div>
    </div>
  );
}
