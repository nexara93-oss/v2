import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getSubject, getChapters, getSubjectLessons } from '../api';
import { useAuth } from '../context/AuthContext';

const subjectIcons = {
  'economie': (
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
    </svg>
  ),
  'comptabilite': (
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>
    </svg>
  ),
  'statistique': (
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
    </svg>
  ),
  'management': (
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  'default': (
    <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
    </svg>
  ),
};

function getSubjectIcon(slug) {
  if (slug.includes('economie') || slug.includes('eco')) return subjectIcons['economie'];
  if (slug.includes('comptab') || slug.includes('compta')) return subjectIcons['comptabilite'];
  if (slug.includes('stat')) return subjectIcons['statistique'];
  if (slug.includes('manage') || slug.includes('admin')) return subjectIcons['management'];
  return subjectIcons['default'];
}

export default function SubjectPage() {
  const { slug } = useParams();
  const { user } = useAuth();
  const [subject, setSubject] = useState(null);
  const [chapters, setChapters] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    setError(false);
    Promise.all([getSubject(slug), getChapters(slug), getSubjectLessons(slug)])
      .then(([s, c, l]) => { setSubject(s); setChapters(c); setLessons(l); })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) return <div className="container loading">Chargement...</div>;
  if (error) return (
    <div className="container" style={{ padding: '80px 20px', textAlign: 'center' }}>
      <h2>Erreur de chargement</h2>
      <Link to="/courses" className="btn btn-orange" style={{ marginTop: 20 }}>Retour au catalogue</Link>
    </div>
  );
  if (!subject) return (
    <div className="container" style={{ padding: '80px 20px', textAlign: 'center' }}>
      <h2>Matière introuvable</h2>
      <Link to="/courses" className="btn btn-orange" style={{ marginTop: 20 }}>Retour au catalogue</Link>
    </div>
  );
  if (user && user.level_slug && subject.level_slug && subject.level_slug !== user.level_slug) {
    return (
      <div className="container" style={{ padding: '80px 20px', textAlign: 'center' }}>
        <h2>Accès restreint</h2>
        <p>Cette matière ne fait pas partie de votre niveau ({subject.level_name}).</p>
        <Link to="/dashboard" className="btn btn-orange" style={{ marginTop: 20 }}>Retour au tableau de bord</Link>
      </div>
    );
  }

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <div className="page-hero-icon" style={{ background: subject.color + '18', color: subject.color }}>
            {getSubjectIcon(slug)}
          </div>
          <h1>{subject.name}</h1>
          <p>{subject.level_name} · {subject.lesson_count} leçons</p>
        </div>
      </section>

      <div className="container" style={{ padding: '48px 20px' }}>
        {chapters.map(chapter => {
          const chapterLessons = lessons.filter(l => l.chapter_id === chapter.id);
          if (chapterLessons.length === 0) return (
            <div key={chapter.id} className="chapter-block">
              <h2 className="chapter-title">{chapter.title}</h2>
              <p className="empty-note">Aucune leçon pour le moment.</p>
            </div>
          );
          return (
            <div key={chapter.id} className="chapter-block">
              <h2 className="chapter-title">{chapter.title}</h2>
              {chapterLessons.map(lesson => (
                <Link key={lesson.id} to={`/lesson/${lesson.id}`} className="video-acc">
                  <summary>
                    <span className="dot upcoming"></span>
                    {lesson.title}
                    <span className="chev">▾</span>
                  </summary>
                  <div className="video-acc-body">
                    <div className="tag-row">
                      {lesson.tags.map((tag, i) => (
                        <span key={i} className="tag">#{tag}</span>
                      ))}
                    </div>
                    <span className="mini-link">{lesson.video_duration}</span>
                  </div>
                </Link>
              ))}
            </div>
          );
        })}
      </div>
    </>
  );
}
