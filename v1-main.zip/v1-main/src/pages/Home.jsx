import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import HeroSlider from '../components/HeroSlider';
import { getLevels } from '../api';

export default function Home() {
  const [levels, setLevels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getLevels()
      .then(setLevels)
      .catch(() => setError("Impossible de charger les niveaux. Veuillez réessayer."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <>
      <HeroSlider />

      <section className="section" id="levels">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Niveaux</span>
            <h2>Choisissez votre niveau scolaire</h2>
            <p>Parcourez les matières disponibles sans avoir besoin de vous connecter</p>
          </div>
          <div className="levels">
            {loading && <p className="empty-note">Chargement…</p>}
            {error && <p className="empty-note">{error}</p>}
            {!loading && !error && levels.map(level => (
              <div key={level.id} className="level-card">
                <div className="level-icon-wrap">
                  <div className="level-icon-ring">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                      {level.slug === 'bac1' ? (
                        <>
                          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
                          <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
                          <line x1="8" y1="7" x2="16" y2="7"/>
                          <line x1="8" y1="11" x2="13" y2="11"/>
                        </>
                      ) : (
                        <>
                          <path d="M22 10v6M2 10l10-5 10 5-10 5z"/>
                          <path d="M6 12v5c3 3 9 3 12 0v-5"/>
                        </>
                      )}
                    </svg>
                  </div>
                </div>
                <h3>{level.name}</h3>
                <p>{level.description}</p>
                <Link to={`/courses?level=${level.slug}`} className="btn btn-ghost btn-block">Parcourir les matières sans inscription</Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container section">
          <div className="section-head">
            <span className="eyebrow">Pourquoi notre plateforme</span>
            <h2>Tout ce dont vous avez besoin au même endroit</h2>
          </div>
          <div className="features-grid">
            <div className="feature">
              <div className="feature-icon-wrap">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <polygon points="23 7 16 12 23 17 23 7"/>
                  <rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
                </svg>
              </div>
              <h3>Explications vidéo</h3>
              <p>Une vidéo explicative claire pour chaque section du programme</p>
            </div>
            <div className="feature">
              <div className="feature-icon-wrap">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                  <polyline points="14 2 14 8 20 8"/>
                  <line x1="16" y1="13" x2="8" y2="13"/>
                  <line x1="16" y1="17" x2="8" y2="17"/>
                </svg>
              </div>
              <h3>Résumés PDF</h3>
              <p>Un résumé prêt à télécharger après chaque leçon</p>
            </div>
            <div className="feature">
              <div className="feature-icon-wrap">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>
                </svg>
              </div>
              <h3>Exercices pratiques</h3>
              <p>Un exercice PDF pour consolider chaque concept</p>
            </div>
          </div>
        </div>
      </section>

      <section className="teachers-section">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Équipe enseignante</span>
            <h2>Des enseignants qui vous mènent vers la réussite</h2>
            <p>Des années d'expérience dans l'enseignement de l'économie et de la comptabilité, avec participation à la correction des examens nationaux</p>
          </div>
          <div className="teachers-grid">
            <div className="teacher-card teacher-card-lg">
              <div className="teacher-avatar">
                <img src="/teachers/said-alaoui.svg" alt="Professeur Said Alaoui" className="teacher-photo" />
                <div className="teacher-badge">15 ans d'expérience</div>
              </div>
              <div className="teacher-info">
                <h3>Professeur Said Alaoui</h3>
                <div className="teacher-role">Professeur d'économie générale</div>
                <p>Enseignant de l'économie et des statistiques pour le baccalauréat, il a participé à la correction de l'examen national pendant plusieurs sessions et s'efforce de simplifier les concepts théoriques à travers des exemples de la réalité marocaine.</p>
                <div className="teacher-tags">
                  <span className="tag">Économie générale</span>
                  <span className="tag">Statistiques</span>
                  <span className="tag">Correction des examens</span>
                </div>
              </div>
            </div>
            <div className="teacher-card teacher-card-lg">
              <div className="teacher-avatar">
                <img src="/teachers/nadia-benali.svg" alt="Professeure Nadia Benali" className="teacher-photo" />
                <div className="teacher-badge">10 ans d'expérience</div>
              </div>
              <div className="teacher-info">
                <h3>Professeure Nadia Benali</h3>
                <div className="teacher-role">Professeure de comptabilité et de gestion</div>
                <p>Spécialiste de la comptabilité générale et de la gestion, elle met l'accent dans ses explications sur les exercices pratiques et les techniques de réponse méthodique à l'examen.</p>
                <div className="teacher-tags">
                  <span className="tag">Comptabilité</span>
                  <span className="tag">Gestion</span>
                  <span className="tag">Exercices pratiques</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
