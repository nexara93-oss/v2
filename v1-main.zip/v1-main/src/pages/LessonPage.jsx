import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getLesson, updateProgress } from '../api';
import { useAuth } from '../context/AuthContext';

export default function LessonPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [lesson, setLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [playerOpen, setPlayerOpen] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [fetchError, setFetchError] = useState('');
  const videoRef = useRef(null);

  useEffect(() => {
    setLesson(null);
    setLoading(true);
    setFetchError('');
    getLesson(id)
      .then((data) => {
        setLesson(data);
        if (user && data.progress) setCompleted(!!data.progress);
      })
      .catch(() => setFetchError('Impossible de charger la leçon. Veuillez réessayer.'))
      .finally(() => setLoading(false));
  }, [id, user]);

  useEffect(() => {
    const blockKeys = (e) => {
      const k = e.key.toLowerCase();
      if (e.ctrlKey || e.metaKey) {
        if (['s', 'p', 'u', 'a'].includes(k)) e.preventDefault();
      }
    };
    document.addEventListener('keydown', blockKeys);
    return () => document.removeEventListener('keydown', blockKeys);
  }, []);

  if (loading) return <div className="container loading">Chargement...</div>;
  if (fetchError) return <div className="container error-msg">{fetchError}</div>;
  if (!lesson) return <div className="container">Leçon introuvable</div>;
  if (user && user.level_slug && lesson.subject_level_slug && lesson.subject_level_slug !== user.level_slug) {
    return (
      <div className="container" style={{ padding: '80px 20px', textAlign: 'center' }}>
        <h2>Accès restreint</h2>
        <p>Cette leçon ne fait pas partie de votre niveau.</p>
        <button className="btn btn-orange" style={{ marginTop: 20 }} onClick={() => navigate('/dashboard')}>Retour au tableau de bord</button>
      </div>
    );
  }

  const videoUrl = lesson.video_url || lesson.file_url || '';
  const isLoggedIn = !!user;

  const handleToggleProgress = () => {
    if (!user) return;
    const next = !completed;
    const prev = completed;
    setCompleted(next);
    updateProgress(user.id, lesson.id, next)
      .catch(() => {
        setCompleted(prev);
        alert("Impossible de mettre à jour votre progression.");
      });
  };

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <div className="page-hero-icon">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="5 3 19 12 5 21 5 3"/>
            </svg>
          </div>
          <h1>{lesson.title}</h1>
          <p>{lesson.chapter_title}</p>
        </div>
      </section>

      <div className="container lesson-wide-container" style={{ padding: '48px 20px' }}>
        <div className="classroom-single classroom-wide">
          <div
            className="video-wrap"
            style={lesson.thumbnail_url && !playerOpen ? { backgroundImage: `url(${lesson.thumbnail_url})`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined}
            onContextMenu={(e) => e.preventDefault()}
            onClick={() => (isLoggedIn ? (videoUrl && setPlayerOpen(true)) : navigate('/login'))}
          >
            {isLoggedIn && playerOpen && videoUrl ? (
              <video
                ref={videoRef}
                src={videoUrl}
                poster={lesson.thumbnail_url || undefined}
                controls
                controlsList="nodownload noremoteplayback"
                disablePictureInPicture
                className="lesson-video"
                onContextMenu={(e) => e.preventDefault()}
                playsInline
              />
            ) : (
              <>
                {isLoggedIn && (
                  <div className="play-btn">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                      <polygon points="5 3 19 12 5 21 5 3"/>
                    </svg>
                  </div>
                )}
                {isLoggedIn && <span className="video-time">{lesson.video_duration}</span>}
                <div className="video-shield">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                  </svg>
                  {isLoggedIn ? 'Vidéo protégée contre l\'enregistrement' : 'Connectez-vous pour regarder la vidéo'}
                </div>
              </>
            )}
          </div>

          <div className="lesson-info">
            <h1>{lesson.title}</h1>
            <p className="lesson-sub">{lesson.chapter_title}</p>
            <div className="tag-row">
              {lesson.tags.map((tag, i) => (
                <span key={i} className="tag">#{tag}</span>
              ))}
            </div>
          </div>

          <div className="attachments">
            {!isLoggedIn && (
              <div className="lesson-lock-note">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
                Connectez-vous pour télécharger le résumé et l'exercice de cette leçon
              </div>
            )}
            {isLoggedIn && lesson.attachments.map(att => (
              <a key={att.id} href={att.file_url} download className="attachment-btn">
                <span className="file-badge">
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
                  </svg>
                </span>
                <span className="file-body">
                  <span className="file-title">{att.title}</span>
                  <span className="file-type">{att.type === 'summary' ? 'Résumé PDF' : 'Exercice PDF'}</span>
                </span>
                <span className="file-dl">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                  </svg>
                </span>
              </a>
            ))}
          </div>

          <button
            className="btn btn-green btn-block"
            disabled={!lesson.next_lesson}
            onClick={() => lesson.next_lesson && navigate(`/lesson/${lesson.next_lesson.id}`)}
          >
            {lesson.next_lesson ? `Vidéo suivante : ${lesson.next_lesson.title}  ←` : 'Aucune prochaine vidéo'}
          </button>

          {isLoggedIn && (
            <button
              className={`btn ${completed ? 'btn-orange' : 'btn-blue'} btn-block`}
              onClick={handleToggleProgress}
            >
              {completed ? 'Réinitialiser la progression' : 'Marquer comme terminé'}
            </button>
          )}

          <div className="chapter-block">
            <h2 className="chapter-title">{lesson.chapter_title}</h2>
            <p className="chapter-desc">
              {lesson.description}
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
