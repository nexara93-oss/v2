import { useState, useEffect } from 'react';
import { getAdminStats, getAdminStudents } from '../../api';

export default function AdminHome() {
  const [stats, setStats] = useState(null);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getAdminStats(), getAdminStudents()])
      .then(([s, st]) => { setStats(s); setStudents(st); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="admin-loading">Chargement...</div>;
  if (!stats) return <div className="admin-loading">Erreur lors du chargement des données</div>;

  const overdueStudents = students.filter(s => s.status === 'overdue');

  return (
    <div className="admin-content">
      <div className="admin-head">
        <h1>Tableau de bord</h1>
        <p>Vue d'ensemble de l'activité de la plateforme.</p>
      </div>

      <div className="admin-stats">
        <div className="admin-stat-card">
          <div className="admin-stat-icon blue">🧑‍🎓</div>
          <div className="admin-stat-body">
            <span className="admin-stat-num">{stats.totalStudents}</span>
            <span className="admin-stat-label">Total des étudiants</span>
          </div>
        </div>
        <div className="admin-stat-card">
          <div className="admin-stat-icon green">✅</div>
          <div className="admin-stat-body">
            <span className="admin-stat-num">{stats.activeStudents}</span>
            <span className="admin-stat-label">Étudiant actif</span>
          </div>
        </div>
        <div className="admin-stat-card">
          <div className="admin-stat-icon purple">📚</div>
          <div className="admin-stat-body">
            <span className="admin-stat-num">{stats.totalLessons}</span>
            <span className="admin-stat-label">Leçon disponible</span>
          </div>
        </div>
        <div className="admin-stat-card">
          <div className="admin-stat-icon orange">⚠️</div>
          <div className="admin-stat-body">
            <span className="admin-stat-num">{stats.overdueStudents}</span>
            <span className="admin-stat-label">Paiements en retard</span>
          </div>
        </div>
      </div>

      <div className="admin-grid">
        <div className="admin-card">
          <h2 className="admin-card-title">Étudiants par niveau</h2>
          <div className="level-bars">
            {stats.byLevel.map(l => {
              const pct = l.students > 0 ? Math.round((l.active / l.students) * 100) : 0;
              return (
                <div className="level-bar-row" key={l.level}>
                  <div className="level-bar-head">
                    <strong>{l.level}</strong>
                    <span>{l.active} actif(s) sur {l.students} · {pct}%</span>
                  </div>
                  <div className="level-bar-track">
                    <span style={{ width: `${pct}%` }}></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="admin-card">
          <h2 className="admin-card-title">Paiements dus</h2>
          <div className="notice-list">
            {overdueStudents.length === 0 ? (
              <p style={{ color: 'var(--text-muted)', textAlign: 'center', padding: 20 }}>Aucun paiement en retard</p>
            ) : (
              overdueStudents.map(n => (
                <div className="notice-row" key={n.id}>
                  <div className="notice-avatar">{n.name.charAt(0)}</div>
                  <div className="notice-body">
                    <strong>{n.name}</strong>
                    <span>{n.level}</span>
                  </div>
                  <div className="notice-status red">En retard</div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
