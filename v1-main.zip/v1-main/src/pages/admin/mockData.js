export const dashboardStats = {
  todayLogins: 47,
  weekLogins: 214,
  byLevel: [
    { level: '2ème Bac', students: 165, active: 148 },
    { level: '1ère Bac', students: 102, active: 91 },
  ],
  totalStudents: 267,
  totalLessons: 68,
  pendingPayments: 6,
};

export const paymentNotices = [
  { id: 1, name: 'Amin Saidi', level: '2ème Bac', dueDate: '2026-09-01', daysLate: 1 },
  { id: 2, name: 'Sara Beniss', level: '1ère Bac', dueDate: '2026-08-28', daysLate: 5 },
  { id: 3, name: 'Youssef El Mrabet', level: '2ème Bac', dueDate: '2026-08-22', daysLate: 11 },
  { id: 4, name: 'Khadija El Amrani', level: '2ème Bac', dueDate: '2026-08-30', daysLate: 3 },
  { id: 5, name: 'Ilyass El Tazi', level: '1ère Bac', dueDate: '2026-09-02', daysLate: 0 },
  { id: 6, name: 'Meriem Bennani', level: '2ème Bac', dueDate: '2026-08-19', daysLate: 14 },
];

export const courseTree = [
  {
    level: '2ème Bac',
    subjects: [
      {
        name: 'Économie générale et statistiques',
        slug: 'economie-2bac',
        color: '#639922',
        icon: '📊',
        parties: [
          {
            name: 'Partie I - Les concepts économiques de base',
            chapters: [
              {
                name: 'Chapitre 1 - Le marché',
                content: {
                  videoUrl: 'https://www.youtube.com/embed/abc123',
                  description: 'Le concept du marché, l\'offre et la demande, l\'équilibre du marché et les prix.',
                  summary: 'resume_marché.pdf',
                  exercice: 'exercice_marché.pdf',
                  correction: 'correction_marché.pdf',
                },
              },
              {
                name: 'Chapitre 2 - Les agents économiques',
                content: {
                  videoUrl: '',
                  description: 'Identifier les acteurs économiques et leurs rôles dans le circuit économique.',
                  summary: '',
                  exercice: 'exercice_agents.pdf',
                  correction: '',
                },
              },
              {
                name: 'Chapitre 3 - Les échanges économiques',
                content: {
                  videoUrl: 'https://www.youtube.com/embed/xyz789',
                  description: 'Les échanges extérieurs, la balance commerciale et ses composantes.',
                  summary: 'resume_echanges.pdf',
                  exercice: '',
                  correction: '',
                },
              },
            ],
          },
          {
            name: 'Partie II - Les relations économiques internationales',
            chapters: [
              {
                name: 'Chapitre 1 - Le commerce international',
                content: {
                  videoUrl: '',
                  description: 'Les théories du commerce international et les politiques protectionnistes.',
                  summary: '',
                  exercice: '',
                  correction: '',
                },
              },
            ],
          },
        ],
      },
      {
        name: 'Gestion',
        slug: 'gestion-2bac',
        color: '#D97706',
        icon: '🏢',
        parties: [
          {
            name: 'Partie I - Les finalités et les fonctions',
            chapters: [
              {
                name: 'Chapitre 1 - L\'organisation',
                content: {
                  videoUrl: 'https://www.youtube.com/embed/org112',
                  description: 'Le concept de l\'organisation administrative et les types de structures.',
                  summary: 'resume_organisation.pdf',
                  exercice: 'exercice_organisation.pdf',
                  correction: 'correction_organisation.pdf',
                },
              },
            ],
          },
        ],
      },
    ],
  },
  {
    level: '1ère Bac',
    subjects: [
      {
        name: 'Économie générale',
        slug: 'economie-1bac',
        color: '#185FA5',
        icon: '📈',
        parties: [
          {
            name: 'Partie I - Les concepts économiques de base',
            chapters: [
              {
                name: 'Chapitre 1 - La science économique',
                content: {
                  videoUrl: 'https://www.youtube.com/embed/scie122',
                  description: 'Définition de la science économique et son objet d\'étude.',
                  summary: 'resume_science.pdf',
                  exercice: 'exercice_science.pdf',
                  correction: '',
                },
              },
            ],
          },
        ],
      },
      {
        name: 'Comptabilité générale',
        slug: 'comptabilite-1bac',
        color: '#534AB7',
        icon: '🧮',
        parties: [
          {
            name: 'Partie I - Les bases de la comptabilité',
            chapters: [
              {
                name: 'Chapitre 1 - Le bilan',
                content: {
                  videoUrl: '',
                  description: 'Le concept du bilan comptable et ses composantes.',
                  summary: '',
                  exercice: '',
                  correction: '',
                },
              },
            ],
          },
        ],
      },
    ],
  },
];

export const students = [
  { id: 1, name: 'Amin Saidi', email: 'amine@gmail.com', level: '2ème Bac', auto: true, paidOn: '2026-09-01', nextDue: '2026-10-01', status: 'overdue', daysEarly: 0 },
  { id: 2, name: 'Sara Beniss', email: 'sara@gmail.com', level: '1ère Bac', auto: false, paidOn: '2026-08-28', nextDue: '2026-09-27', status: 'overdue', daysEarly: 0 },
  { id: 3, name: 'Youssef El Mrabet', email: 'youssef@gmail.com', level: '2ème Bac', auto: true, paidOn: '2026-08-22', nextDue: '2026-09-21', status: 'overdue', daysEarly: 0 },
  { id: 4, name: 'Mohamed El Idrissi', email: 'med@gmail.com', level: '2ème Bac', auto: true, paidOn: '2026-09-05', nextDue: '2026-10-05', status: 'active', daysEarly: 23 },
  { id: 5, name: 'Khadija El Amrani', email: 'khadija@gmail.com', level: '2ème Bac', auto: false, paidOn: '2026-08-30', nextDue: '2026-09-29', status: 'overdue', daysEarly: 0 },
  { id: 6, name: 'Ilyass El Tazi', email: 'ilyass@gmail.com', level: '1ère Bac', auto: true, paidOn: '2026-09-02', nextDue: '2026-10-02', status: 'active', daysEarly: 28 },
  { id: 7, name: 'Meriem Bennani', email: 'meriem@gmail.com', level: '2ème Bac', auto: false, paidOn: '2026-08-19', nextDue: '2026-09-18', status: 'overdue', daysEarly: 0 },
  { id: 8, name: 'Omar El Fassi', email: 'omar@gmail.com', level: '1ère Bac', auto: true, paidOn: '2026-09-06', nextDue: '2026-10-06', status: 'disabled', daysEarly: 24 },
];

export const mediaFiles = [
  { id: 1, name: 'resume_marché.pdf', type: 'pdf', category: 'Résumés', size: '1.2 MB', date: '2026-08-10' },
  { id: 2, name: 'exercice_marché.pdf', type: 'pdf', category: 'Exercices', size: '840 KB', date: '2026-08-10' },
  { id: 3, name: 'correction_marché.pdf', type: 'pdf', category: 'Corrections', size: '1.1 MB', date: '2026-08-11' },
  { id: 4, name: 'lesson_marche.mp4', type: 'video', category: 'Vidéos', size: '128 MB', date: '2026-08-09' },
  { id: 5, name: 'resume_echanges.pdf', type: 'pdf', category: 'Résumés', size: '980 KB', date: '2026-08-15' },
  { id: 6, name: 'exam_blanc_1.pdf', type: 'pdf', category: 'Examens', size: '1.5 MB', date: '2026-08-20' },
  { id: 7, name: 'correction_organisation.pdf', type: 'pdf', category: 'Corrections', size: '900 KB', date: '2026-08-22' },
  { id: 8, name: 'cours_gestion.mp4', type: 'video', category: 'Vidéos', size: '95 MB', date: '2026-08-24' },
];
