import { useState, useRef, useEffect } from 'react';
import { getAdminMedia, addMedia, deleteMedia } from '../../api';

const typeMeta = {
  pdf: { icon: '📄', color: '#B45309', bg: '#FDE8D8' },
  video: { icon: '🎬', color: '#185FA5', bg: '#E3EEFB' },
};

export default function AdminMedia() {
  const [files, setFiles] = useState([]);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [showUpload, setShowUpload] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newFile, setNewFile] = useState({ name: '', type: 'pdf', category: 'Résumés', size: '' });

  useEffect(() => {
    getAdminMedia()
      .then(setFiles)
      .finally(() => setLoading(false));
  }, []);

  const categories = ['all', ...new Set(files.map(f => f.category))];

  const filtered = files.filter(f =>
    (cat === 'all' || f.category === cat) &&
    (!q || f.name.includes(q))
  );

  const handleAdd = async () => {
    if (!newFile.name) return;
    const result = await addMedia(newFile);
    if (result.id) {
      setFiles(prev => [result, ...prev]);
      setNewFile({ name: '', type: 'pdf', category: 'Résumés', size: '' });
      setShowUpload(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce fichier ?')) return;
    await deleteMedia(id);
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  if (loading) return <div className="admin-loading">Chargement...</div>;

  return (
    <div className="admin-content">
      <div className="admin-head">
        <div>
          <h1>Gestion des fichiers</h1>
          <p>Télécharger et organiser les vidéos et les fichiers pédagogiques.</p>
        </div>
        <button className="admin-btn admin-btn-orange" onClick={() => setShowUpload(!showUpload)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          Ajouter un fichier
        </button>
      </div>

      {showUpload && (
        <div className="admin-add-form">
          <div className="admin-form-row">
            <input type="text" placeholder="Nom du fichier" value={newFile.name} onChange={e => setNewFile({...newFile, name: e.target.value})} />
            <select value={newFile.type} onChange={e => setNewFile({...newFile, type: e.target.value})}>
              <option value="pdf">PDF</option>
              <option value="video">Vidéo</option>
            </select>
            <select value={newFile.category} onChange={e => setNewFile({...newFile, category: e.target.value})}>
              <option value="Résumés">Résumés</option>
              <option value="Exercices">Exercices</option>
              <option value="Vidéos">Vidéos</option>
              <option value="Examens">Examens</option>
            </select>
            <input type="text" placeholder="Taille (ex : 1.2 MB)" value={newFile.size} onChange={e => setNewFile({...newFile, size: e.target.value})} />
            <button className="admin-btn admin-btn-green" onClick={handleAdd}>Enregistrer</button>
          </div>
        </div>
      )}

      <div className="media-toolbar">
        <div className="media-search-wrap">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input
            className="media-search"
            type="text"
            placeholder="Rechercher un fichier..."
            value={q}
            onChange={e => setQ(e.target.value)}
          />
        </div>
        <div className="filter-bar">
          {categories.map(c => (
            <button
              key={c}
              className={`filter-pill ${cat === c ? 'active' : ''}`}
              onClick={() => setCat(c)}
            >
              {c === 'all' ? 'Tous' : c}
            </button>
          ))}
        </div>
      </div>

      <div className="media-stats-row">
        <div className="media-stat">
          <span className="media-stat-num">{files.filter(f => f.type === 'video').length}</span>
          <span className="media-stat-label">Vidéo</span>
        </div>
        <div className="media-stat">
          <span className="media-stat-num">{files.filter(f => f.type === 'pdf').length}</span>
          <span className="media-stat-label">Fichier PDF</span>
        </div>
        <div className="media-stat">
          <span className="media-stat-num">{files.length}</span>
          <span className="media-stat-label">Total des fichiers</span>
        </div>
      </div>

      <div className="media-grid">
        {filtered.map(f => {
          const meta = typeMeta[f.type] || typeMeta.pdf;
          return (
            <div className="media-card" key={f.id}>
              <div className="media-thumb" style={{ background: meta.bg }}>
                <span className="media-thumb-icon" style={{ color: meta.color }}>{meta.icon}</span>
              </div>
              <div className="media-body">
                <strong>{f.name}</strong>
                <div className="media-details">
                  <span className="media-category">{f.category}</span>
                  <span className="media-size">{f.size}</span>
                </div>
                <span className="media-date">{f.uploaded_at}</span>
              </div>
              <div className="media-actions">
                <button className="mini-btn danger" onClick={() => handleDelete(f.id)} title="Supprimer">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="admin-empty">
          <div className="empty-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          </div>
          <p>Aucun fichier correspondant</p>
        </div>
      )}
    </div>
  );
}
