import { useState, useEffect } from 'react';
import { getUserActivity, getWatchHistory } from '../../api';

export default function AdminActivity() {
  const [activity, setActivity] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('users');
  const [search, setSearch] = useState('');

  useEffect(() => {
    Promise.all([getUserActivity(), getWatchHistory()])
      .then(([a, h]) => { setActivity(a); setHistory(h); })
      .finally(() => setLoading(false));
  }, []);

  const filteredUsers = activity.filter(a => {
    const q = search.toLowerCase();
    return !q || (a.name || '').toLowerCase().includes(q) || (a.email || '').toLowerCase().includes(q);
  });

  const filteredHistory = history.filter(h => {
    const q = search.toLowerCase();
    return !q || (h.user_name || '').toLowerCase().includes(q) || (h.lesson_title || '').toLowerCase().includes(q);
  });

  if (loading) return <div className="admin-loading"><div className="spinner"></div>Chargement...</div>;

  return (
    <div className="admin-content">
      <div className="admin-page-head">
        <div>
          <h1>Activité des utilisateurs</h1>
          <p>Suivez qui regarde les leçons et la durée de visionnage</p>
        </div>
      </div>

      <div className="admin-toolbar">
        <div className="search-box">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Rechercher..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="filter-pills">
          <button className={`pill ${tab === 'users' ? 'active' : ''}`} onClick={() => setTab('users')}>Utilisateurs ({activity.length})</button>
          <button className={`pill ${tab === 'history' ? 'active' : ''}`} onClick={() => setTab('history')}>Historique de visionnage ({history.length})</button>
        </div>
      </div>

      {tab === 'users' && (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Utilisateur</th>
                <th>Leçons regardées</th>
                <th>Total des heures</th>
                <th>Dernière activité</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.length === 0 ? (
                <tr><td colSpan="4" className="empty-table">Aucune activité</td></tr>
              ) : filteredUsers.map(a => (
                <tr key={a.id}>
                  <td>
                    <div className="table-user">
                      <div className="avatar">{a.name.charAt(0)}</div>
                      <div>
                        <strong>{a.name}</strong>
                        <span className="email">{a.email}</span>
                      </div>
                    </div>
                  </td>
                  <td><span className="badge green">{a.lessons_watched} leçon(s)</span></td>
                  <td><span className="hours-badge">{a.total_hours} heure(s)</span></td>
                  <td>{a.last_active ? new Date(a.last_active).toLocaleDateString('fr-FR') : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'history' && (
        <div className="admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th>Utilisateur</th>
                <th>Leçon</th>
                <th>Durée</th>
                <th>Statut</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {filteredHistory.length === 0 ? (
                <tr><td colSpan="5" className="empty-table">Aucun historique</td></tr>
              ) : filteredHistory.map(h => (
                <tr key={h.id}>
                  <td>
                    <div className="table-user">
                      <div className="avatar">{h.user_name.charAt(0)}</div>
                      <div>
                        <strong>{h.user_name}</strong>
                        <span className="email">{h.email}</span>
                      </div>
                    </div>
                  </td>
                  <td>{h.lesson_title}</td>
                  <td>{h.watch_duration ? `${Math.floor(h.watch_duration / 60)}:${(h.watch_duration % 60).toString().padStart(2, '0')}` : '0:00'}</td>
                  <td>
                    <span className={`status ${h.completed ? 'active' : 'overdue'}`}>
                      {h.completed ? 'Terminé' : 'En cours'}
                    </span>
                  </td>
                  <td>{new Date(h.watched_at).toLocaleDateString('fr-FR')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
