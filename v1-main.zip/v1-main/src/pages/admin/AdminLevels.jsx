import { useState, useEffect } from 'react';
import { getAdminLevels, addLevel, updateLevel, deleteLevel } from '../../api';

export default function AdminLevels() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ name: '', slug: '', icon: '', description: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    getAdminLevels().then(setRows).finally(() => setLoading(false));
  }, []);

  const resetForm = () => {
    setForm({ name: '', slug: '', icon: '', description: '' });
    setEditId(null);
    setError('');
  };

  const openAdd = () => { resetForm(); setShowAdd(true); };
  const openEdit = (row) => { setForm({ name: row.name, slug: row.slug, icon: row.icon || '', description: row.description || '' }); setEditId(row.id); setShowAdd(true); };

  const handleSubmit = async () => {
    if (!form.name || !form.slug) { setError('Nom et slug requis'); return; }
    setError('');
    try {
      const result = editId
        ? await updateLevel(editId, form)
        : await addLevel(form);
      if (result.error) { setError(result.error); return; }
      if (editId) {
        setRows(prev => prev.map(r => r.id === editId ? { ...r, ...form } : r));
      } else {
        setRows(prev => [...prev, { id: result.id, ...form }]);
      }
      setShowAdd(false);
      resetForm();
    } catch (e) {
      setError(e.message || 'Erreur');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Supprimer ce niveau ?')) return;
    try {
      const result = await deleteLevel(id);
      if (result.error) { alert(result.error); return; }
      setRows(prev => prev.filter(r => r.id !== id));
    } catch (e) {
      alert('Erreur : ' + (e.message || e));
    }
  };

  if (loading) return <div className="admin-loading"><div className="spinner"></div>Chargement...</div>;

  return (
    <div className="admin-content">
      <div className="admin-page-head">
        <div>
          <h1>Gestion des niveaux</h1>
          <p>Ajouter, modifier ou supprimer les niveaux scolaires</p>
        </div>
        <button className="admin-btn primary" onClick={openAdd}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nouveau niveau
        </button>
      </div>

      {showAdd && (
        <div className="admin-form-card">
          <h3>{editId ? 'Modifier le niveau' : 'Ajouter un niveau'}</h3>
          {error && <div className="error-alert">{error}</div>}
          <div className="form-grid">
            <div className="form-group">
              <label>Nom du niveau</label>
              <input type="text" placeholder="ex: 1ère année" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Slug (identifiant URL)</label>
              <input type="text" placeholder="ex: bac1" value={form.slug} onChange={e => setForm({...form, slug: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Icône (emoji)</label>
              <input type="text" placeholder="ex: 📘" value={form.icon} onChange={e => setForm({...form, icon: e.target.value})} />
            </div>
            <div className="form-group" style={{ gridColumn: '1 / -1' }}>
              <label>Description</label>
              <input type="text" placeholder="Description courte" value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => { setShowAdd(false); resetForm(); }}>Annuler</button>
            <button className="admin-btn primary" onClick={handleSubmit}>{editId ? 'Enregistrer' : 'Ajouter'}</button>
          </div>
        </div>
      )}

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Icône</th>
              <th>Nom</th>
              <th>Slug</th>
              <th>Description</th>
              <th style={{ width: 120 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id}>
                <td>{r.id}</td>
                <td style={{ fontSize: '1.4em' }}>{r.icon || '—'}</td>
                <td><strong>{r.name}</strong></td>
                <td><code>{r.slug}</code></td>
                <td>{r.description || '—'}</td>
                <td>
                  <button className="admin-btn small ghost" onClick={() => openEdit(r)} title="Modifier">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>
                  </button>
                  <button className="admin-btn small danger" onClick={() => handleDelete(r.id)} title="Supprimer">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                  </button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={6} style={{ textAlign: 'center', padding: 32, color: 'var(--text-muted)' }}>Aucun niveau</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
