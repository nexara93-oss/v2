import { useState, useEffect } from 'react';
import { getAdminStudents, addStudent, updateStudent, deleteStudent, resetStudentIP } from '../../api';

const statusMeta = {
  active: { label: 'Payé', cls: 'active' },
  overdue: { label: 'En retard', cls: 'overdue' },
  disabled: { label: 'Désactivé', cls: 'disabled' },
};

export default function AdminStudents() {
  const [rows, setRows] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', level: '1ère Bac' });
  const [search, setSearch] = useState('');
  const [newPassword, setNewPassword] = useState(null);
  const [newStudentInfo, setNewStudentInfo] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    getAdminStudents().then(setRows).finally(() => setLoading(false));
  }, []);

  const filtered = rows.filter(r => {
    const matchFilter = filter === 'all' || r.status === filter;
    const q = search.toLowerCase();
    const matchSearch = !q || (r.name || '').toLowerCase().includes(q) || (r.email || '').toLowerCase().includes(q);
    return matchFilter && matchSearch;
  });

  const handleAdd = async () => {
    if (!form.name || !form.email) return;
    setError('');
    setNewPassword(null);
    setNewStudentInfo(null);
    try {
      const result = await addStudent(form.name, form.email, form.level);
      console.log('Add student result:', result);
      if (result.error) {
        setError(result.error);
      } else if (result.id) {
        const { password, ...safe } = result;
        setRows(prev => [safe, ...prev]);
        setNewPassword(password);
        setNewStudentInfo({ name: result.name, email: result.email });
        setForm({ name: '', email: '', level: '1ère Bac' });
        setShowAdd(false);
      }
    } catch (e) {
      alert('Erreur : ' + (e.message || e));
    }
  };

  const markPaid = async (id) => {
    try {
      const d = new Date();
      const today = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
      const next = new Date();
      next.setDate(next.getDate() + 30);
      const nextDue = `${next.getFullYear()}-${String(next.getMonth()+1).padStart(2,'0')}-${String(next.getDate()).padStart(2,'0')}`;
      const result = await updateStudent(id, { status: 'active', paid_on: today, next_due: nextDue });
      if (result && result.success === false) return;
      setRows(prev => prev.map(r => r.id === id ? { ...r, status: 'active', paid_on: today, next_due: nextDue } : r));
    } catch (e) {
      alert('Erreur : ' + (e.message || e));
    }
  };

  const toggleAccount = async (id) => {
    const student = rows.find(r => r.id === id);
    const newStatus = student.status === 'disabled' ? 'active' : 'disabled';
    if (newStatus === 'disabled' && !confirm('Désactiver ce compte ? L\'étudiant ne pourra plus se connecter.')) return;
    try {
      const result = await updateStudent(id, { status: newStatus });
      if (result && result.success === false) return;
      setRows(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
    } catch (e) {
      alert('Erreur : ' + (e.message || e));
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cet étudiant ?')) return;
    try {
      const result = await deleteStudent(id);
      if (result && result.success === false) return;
      setRows(prev => prev.filter(r => r.id !== id));
    } catch (e) {
      alert('Erreur : ' + (e.message || e));
    }
  };

  const handleResetIP = async (id) => {
    if (!confirm('Réinitialiser l\'appareil/IP ? L\'étudiant pourra se connecter depuis un nouvel appareil.')) return;
    try {
      const result = await resetStudentIP(id);
      if (result && result.success === false) return;
      setRows(prev => prev.map(r => r.id === id ? { ...r, ip_address: null, last_login_ip: null } : r));
    } catch (e) {
      alert('Erreur : ' + (e.message || e));
    }
  };

  if (loading) return <div className="admin-loading"><div className="spinner"></div>Chargement...</div>;

  return (
    <div className="admin-content">
      <div className="admin-page-head">
        <div>
          <h1>Gestion des étudiants</h1>
          <p>Ajouter, supprimer et gérer les comptes étudiants</p>
        </div>
        <button className="admin-btn primary" onClick={() => setShowAdd(!showAdd)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nouvel étudiant
        </button>
      </div>

      {showAdd && (
        <div className="admin-form-card">
          <h3>Ajouter un étudiant</h3>
          {error && <div className="error-alert">{error}</div>}
          <div className="form-grid">
            <div className="form-group">
              <label>Nom de l'étudiant</label>
              <input type="text" placeholder="Nom complet" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Adresse e-mail</label>
              <input type="email" placeholder="email@example.com" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Niveau</label>
              <select value={form.level} onChange={e => setForm({...form, level: e.target.value})}>
                <option value="1ère Bac">1ère année</option>
                <option value="2ème Bac">2ème année</option>
              </select>
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => setShowAdd(false)}>Annuler</button>
            <button className="admin-btn primary" onClick={handleAdd}>Enregistrer</button>
          </div>
        </div>
      )}

      {newPassword && (
        <div className="password-card">
          <div className="password-card-header">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            <h3>Compte créé avec succès</h3>
          </div>
          <div className="password-info">
            <div className="password-row">
              <span className="password-label">Nom :</span>
              <span className="password-value">{newStudentInfo?.name}</span>
            </div>
            <div className="password-row">
              <span className="password-label">E-mail :</span>
              <span className="password-value">{newStudentInfo?.email}</span>
            </div>
            <div className="password-row highlight">
              <span className="password-label">Mot de passe :</span>
              <div className="password-box">
                <code>{newPassword}</code>
                <button className="copy-btn" onClick={() => { navigator.clipboard.writeText(newPassword); alert('Copié !'); }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                </button>
              </div>
            </div>
          </div>
          <div className="password-warning">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            Copiez le mot de passe et envoyez-le à l'étudiant — il ne sera plus affiché
          </div>
          <button className="admin-btn ghost" onClick={() => { setNewPassword(null); setNewStudentInfo(null); }}>Fermer</button>
        </div>
      )}

      <div className="admin-toolbar">
        <div className="search-box">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="Rechercher par nom ou e-mail..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="filter-pills">
          <button className={`pill ${filter === 'all' ? 'active' : ''}`} onClick={() => setFilter('all')}>Tous ({rows.length})</button>
          <button className={`pill ${filter === 'active' ? 'active' : ''}`} onClick={() => setFilter('active')}>Payé ({rows.filter(r => r.status === 'active').length})</button>
          <button className={`pill ${filter === 'overdue' ? 'active' : ''}`} onClick={() => setFilter('overdue')}>En retard ({rows.filter(r => r.status === 'overdue').length})</button>
          <button className={`pill ${filter === 'disabled' ? 'active' : ''}`} onClick={() => setFilter('disabled')}>Désactivé ({rows.filter(r => r.status === 'disabled').length})</button>
        </div>
      </div>

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Étudiant</th>
              <th>Niveau</th>
              <th>Dernier paiement</th>
              <th>Prochain paiement</th>
              <th>Statut</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan="6" className="empty-table">Aucun résultat</td></tr>
            ) : filtered.map(s => (
              <tr key={s.id}>
                <td>
                  <div className="table-user">
                    <div className="avatar">{s.name.charAt(0)}</div>
                    <div>
                      <strong>{s.name}</strong>
                      <span className="email">{s.email}</span>
                    </div>
                  </div>
                </td>
                <td><span className="badge">{s.level}</span></td>
                <td>{s.paid_on || '—'}</td>
                <td>{s.next_due || '—'}</td>
                <td><span className={`status ${(statusMeta[s.status] || { label: s.status, cls: 'default' }).cls}`}>{(statusMeta[s.status] || { label: s.status, cls: 'default' }).label}</span></td>
                <td>
                  <div className="row-actions">
                    {s.status !== 'disabled' && (
                      <button className="action-btn green" onClick={() => markPaid(s.id)} title="Marquer comme payé">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                      </button>
                    )}
                    <button className="action-btn yellow" onClick={() => toggleAccount(s.id)} title={s.status === 'disabled' ? 'Activer' : 'Désactiver'}>
                      {s.status === 'disabled' ? (
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                      ) : (
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                      )}
                    </button>
                    <button className="action-btn blue" onClick={() => handleResetIP(s.id)} title="Réinitialiser l'appareil/IP">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>
                    </button>
                    <button className="action-btn red" onClick={() => handleDelete(s.id)} title="Supprimer">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
