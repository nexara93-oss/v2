import { useState, useEffect } from 'react';
import { getLevels, getSubjects, getSubjectTree, addSubject, updateSubject, addChapter, updateChapter, deleteChapter, addLesson, updateLesson, deleteLesson, uploadFile, uploadVideo, uploadPdf } from '../../api';

export default function AdminCourses() {
  const [levels, setLevels] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [treeData, setTreeData] = useState({});
  const [expanded, setExpanded] = useState({});
  const [loading, setLoading] = useState(true);
  const [showAddSubject, setShowAddSubject] = useState(false);
  const [showEditSubject, setShowEditSubject] = useState(false);
  const [editingSubject, setEditingSubject] = useState(null);
  const [subjectForm, setSubjectForm] = useState({ name: '', slug: '', color: '#185FA5', level_id: 1, icon: '📚', thumbnail_url: '' });
  const [editSubjectForm, setEditSubjectForm] = useState({ name: '', icon: '', color: '', thumbnail_url: '' });
  const [uploading, setUploading] = useState(false);

  const [showAddChapter, setShowAddChapter] = useState(false);
  const [chapterSubjectId, setChapterSubjectId] = useState(null);
  const [chapterTitle, setChapterTitle] = useState('');
  const [showEditChapter, setShowEditChapter] = useState(false);
  const [editingChapter, setEditingChapter] = useState(null);
  const [editChapterTitle, setEditChapterTitle] = useState('');

  const [showAddLesson, setShowAddLesson] = useState(false);
  const [lessonChapterId, setLessonChapterId] = useState(null);
  const [lessonForm, setLessonForm] = useState({ title: '', description: '', video_url: '', video_duration: '', tags: '', thumbnail_url: '', summary_url: '', exercise_url: '' });
  const [editingLessonId, setEditingLessonId] = useState(null);
  const [formError, setFormError] = useState('');
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [uploadingLessonThumb, setUploadingLessonThumb] = useState(false);
  const [uploadingSummary, setUploadingSummary] = useState(false);
  const [uploadingExercise, setUploadingExercise] = useState(false);

  const loadTree = async (subjectId) => {
    const tree = await getSubjectTree(subjectId);
    setTreeData(prev => ({ ...prev, [subjectId]: tree }));
  };

  useEffect(() => {
    Promise.all([getLevels(), getSubjects()])
      .then(([l, s]) => { setLevels(l); setSubjects(s); })
      .finally(() => setLoading(false));
  }, []);

  const toggle = (key) => setExpanded(prev => ({ ...prev, [key]: !prev[key] }));

  const toggleSubject = async (subject) => {
    const nextExpanded = !expanded[`sub-${subject.id}`];
    toggle(`sub-${subject.id}`);
    if (nextExpanded && !treeData[subject.id]) {
      await loadTree(subject.id);
    }
  };

  const grouped = levels.map(level => ({
    ...level,
    subjects: subjects.filter(s => s.level_slug === level.slug),
  }));

  const [subjectFormError, setSubjectFormError] = useState('');

  const handleAddSubject = async () => {
    if (!subjectForm.name || !subjectForm.slug) return;
    setSubjectFormError('');
    try {
      const result = await addSubject(subjectForm);
      if (result.error) {
        setSubjectFormError(result.error);
        return;
      }
      if (result.id) {
        setSubjects(prev => [...prev, { ...result, level_slug: levels.find(l => l.id === subjectForm.level_id)?.slug || 'bac1' }]);
        setSubjectForm({ name: '', slug: '', color: '#185FA5', level_id: 1, icon: '📚', thumbnail_url: '' });
        setShowAddSubject(false);
      }
    } catch (err) {
      setSubjectFormError('Erreur lors de l\'opération.');
    }
  };

  const handleAddThumbnail = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await uploadFile(file);
      if (result.url) setSubjectForm(prev => ({ ...prev, thumbnail_url: result.url }));
    } catch (err) { console.error('Upload failed:', err); }
    setUploading(false);
  };

  const handleEditSubject = (subject) => {
    setEditingSubject(subject);
    setEditSubjectForm({ name: subject.name, icon: subject.icon || '', color: subject.color || '#185FA5', thumbnail_url: subject.thumbnail_url || '' });
    setShowEditSubject(true);
  };

  const [editSubjectFormError, setEditSubjectFormError] = useState('');

  const handleUpdateSubject = async () => {
    if (!editingSubject || !editSubjectForm.name) return;
    setEditSubjectFormError('');
    try {
      const result = await updateSubject(editingSubject.id, editSubjectForm);
      if (result.error) {
        setEditSubjectFormError(result.error);
        return;
      }
      if (result.success) {
        setSubjects(prev => prev.map(s => s.id === editingSubject.id ? { ...s, ...editSubjectForm } : s));
        setShowEditSubject(false);
        setEditingSubject(null);
      }
    } catch (err) {
      setEditSubjectFormError('Erreur lors de l\'opération.');
    }
  };

  const handleUploadThumbnail = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await uploadFile(file);
      if (result.url) setEditSubjectForm(prev => ({ ...prev, thumbnail_url: result.url }));
    } catch (err) { console.error('Upload failed:', err); }
    setUploading(false);
  };

  const openAddChapter = (subjectId) => {
    setChapterSubjectId(subjectId);
    setChapterTitle('');
    setShowAddChapter(true);
  };

  const [chapterFormError, setChapterFormError] = useState('');

  const handleAddChapter = async () => {
    if (!chapterTitle || !chapterSubjectId) return;
    setChapterFormError('');
    try {
      const result = await addChapter(chapterSubjectId, chapterTitle);
      if (result.error) {
        setChapterFormError(result.error);
        return;
      }
      if (result.id) {
        await loadTree(chapterSubjectId);
        setShowAddChapter(false);
        setChapterTitle('');
      }
    } catch (err) {
      setChapterFormError('Erreur lors de l\'opération.');
    }
  };

  const openEditChapter = (chapter) => {
    setEditingChapter(chapter);
    setEditChapterTitle(chapter.title);
    setShowEditChapter(true);
  };

  const handleUpdateChapter = async () => {
    if (!editingChapter) return;
    try {
      const result = await updateChapter(editingChapter.id, editChapterTitle);
      if (result.error) {
        setChapterFormError(result.error);
        return;
      }
      if (result.success) {
        const subjectId = editingChapter.subject_id;
        await loadTree(subjectId);
        setShowEditChapter(false);
        setEditingChapter(null);
      }
    } catch (err) {
      setChapterFormError('Erreur lors de l\'opération.');
    }
  };

  const handleDeleteChapter = async (chapter) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette unité et toutes ses leçons ?')) return;
    try {
      const result = await deleteChapter(chapter.id);
      if (result.error) {
        setChapterFormError(result.error);
        return;
      }
      if (result.success) {
        await loadTree(chapter.subject_id);
      }
    } catch (err) {
      setChapterFormError('Erreur lors de l\'opération.');
    }
  };

  const openAddLesson = (chapter) => {
    setLessonChapterId(chapter.id);
    setLessonForm({ title: '', description: '', video_url: '', video_duration: '', tags: '', thumbnail_url: '', summary_url: '', exercise_url: '' });
    setEditingLessonId(null);
    setFormError('');
    setShowAddLesson(true);
  };

  const openEditLesson = (lesson, chapterId) => {
    setLessonChapterId(chapterId);
    setEditingLessonId(lesson.id);
    setLessonForm({
      title: lesson.title || '',
      description: lesson.description || '',
      video_url: lesson.video_url || '',
      video_duration: lesson.video_duration || '',
      tags: lesson.tags || '',
      thumbnail_url: lesson.thumbnail_url || '',
      summary_url: lesson.summary_url || '',
      exercise_url: lesson.exercise_url || '',
    });
    setFormError('');
    setShowAddLesson(true);
  };

  const detectVideoDuration = (file) => {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        const seconds = video.duration;
        URL.revokeObjectURL(url);
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        resolve(`${mins}:${secs < 10 ? '0' : ''}${secs}`);
      };
      video.onerror = () => {
        URL.revokeObjectURL(url);
        resolve('');
      };
      video.src = url;
    });
  };

  const handleLessonVideoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingVideo(true);
    try {
      const duration = await detectVideoDuration(file);
      const result = await uploadVideo(file);
      if (result.url) {
        setLessonForm(prev => ({ ...prev, video_url: result.url, video_duration: duration || prev.video_duration }));
      }
    } catch (err) {
      console.error('Video upload failed:', err);
    }
    setUploadingVideo(false);
  };

  const handleLessonThumbUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingLessonThumb(true);
    try {
      const result = await uploadFile(file);
      if (result.url) {
        setLessonForm(prev => ({ ...prev, thumbnail_url: result.url }));
      }
    } catch (err) {
      console.error('Upload failed:', err);
    }
    setUploadingLessonThumb(false);
  };

  const handleSummaryUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingSummary(true);
    try {
      const result = await uploadPdf(file);
      if (result.url) {
        setLessonForm(prev => ({ ...prev, summary_url: result.url }));
      }
    } catch (err) {
      console.error('Summary upload failed:', err);
    }
    setUploadingSummary(false);
  };

  const handleExerciseUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingExercise(true);
    try {
      const result = await uploadPdf(file);
      if (result.url) {
        setLessonForm(prev => ({ ...prev, exercise_url: result.url }));
      }
    } catch (err) {
      console.error('Exercise upload failed:', err);
    }
    setUploadingExercise(false);
  };

  const handleAddLesson = async () => {
    if (!lessonForm.title || !lessonChapterId) return;
    setFormError('');
    try {
      let result;
      if (editingLessonId) {
        result = await updateLesson(editingLessonId, { ...lessonForm, chapter_id: lessonChapterId });
      } else {
        result = await addLesson({ ...lessonForm, chapter_id: lessonChapterId });
      }
      if (result.error) {
        setFormError(result.error);
        return;
      }
      if (result.id || result.success) {
        setShowAddLesson(false);
        setEditingLessonId(null);
        const subjectId = chapterSubjectIdFor(lessonChapterId);
        if (subjectId) await loadTree(subjectId);
      }
    } catch (err) {
      setFormError('Erreur lors de l\'opération.');
    }
  };

  const chapterSubjectIdFor = (chapterId) => {
    for (const subjId in treeData) {
      const found = treeData[subjId].find(ch => ch.id === chapterId);
      if (found) return Number(subjId);
    }
    return null;
  };

  const handleDeleteLesson = async (lesson, chapterId) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette leçon ?')) return;
    try {
      const result = await deleteLesson(lesson.id);
      if (result.error) {
        setFormError(result.error);
        return;
      }
      if (result.success) {
        const subjectId = chapterSubjectIdFor(chapterId);
        if (subjectId) await loadTree(subjectId);
      }
    } catch (err) {
      setFormError('Erreur lors de l\'opération.');
    }
  };

  if (loading) return <div className="admin-loading"><div className="spinner"></div>Chargement...</div>;

  return (
    <div className="admin-content">
      <div className="admin-page-head">
        <div>
          <h1>Cours et leçons</h1>
          <p>Gérer les matières, les unités, les leçons et le contenu pédagogique</p>
        </div>
        <button className="admin-btn primary" onClick={() => setShowAddSubject(!showAddSubject)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Nouvelle matière
        </button>
      </div>

      {showAddSubject && (
        <div className="admin-form-card">
          <h3>Ajouter une nouvelle matière</h3>
          {subjectFormError && <div className="error-alert">{subjectFormError}</div>}
          <div className="form-grid">
            <div className="form-group">
              <label>Nom de la matière</label>
              <input type="text" placeholder="Nom de la matière" value={subjectForm.name} onChange={e => setSubjectForm({...subjectForm, name: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Identifiant (Slug)</label>
              <input type="text" placeholder="e.g. economie" value={subjectForm.slug} onChange={e => setSubjectForm({...subjectForm, slug: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Niveau</label>
              <select value={subjectForm.level_id} onChange={e => setSubjectForm({...subjectForm, level_id: Number(e.target.value)})}>
                {levels.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Couleur</label>
              <input type="color" value={subjectForm.color} onChange={e => setSubjectForm({...subjectForm, color: e.target.value})} />
            </div>
            <div className="form-group full">
              <label>Image miniature (affichée sur les cartes de l'élève)</label>
              <div className="file-upload-row">
                <input type="file" accept="image/*" onChange={handleAddThumbnail} id="subject-add-upload" className="file-input-hidden" />
                <label htmlFor="subject-add-upload" className="admin-btn ghost upload-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  {uploading ? 'Téléchargement...' : 'Choisir une image depuis l\'appareil'}
                </label>
              </div>
              {subjectForm.thumbnail_url && (
                <div className="thumb-preview">
                  <img src={subjectForm.thumbnail_url} alt="preview" />
                </div>
              )}
              <input type="text" placeholder="Ou saisir manuellement le lien de l'image" value={subjectForm.thumbnail_url} onChange={e => setSubjectForm({...subjectForm, thumbnail_url: e.target.value})} style={{ marginTop: '8px' }} />
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => setShowAddSubject(false)}>Annuler</button>
            <button className="admin-btn primary" onClick={handleAddSubject}>Enregistrer</button>
          </div>
        </div>
      )}

      {showEditSubject && editingSubject && (
        <div className="admin-form-card">
          <h3>Modifier la matière : {editingSubject.name}</h3>
          {editSubjectFormError && <div className="error-alert">{editSubjectFormError}</div>}
          <div className="form-grid">
            <div className="form-group">
              <label>Nom de la matière</label>
              <input type="text" placeholder="Nom de la matière" value={editSubjectForm.name} onChange={e => setEditSubjectForm({...editSubjectForm, name: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Icône</label>
              <input type="text" placeholder="Exemple : 📘 ou 🎓" value={editSubjectForm.icon} onChange={e => setEditSubjectForm({...editSubjectForm, icon: e.target.value})} />
            </div>
            <div className="form-group">
              <label>Couleur</label>
              <input type="color" value={editSubjectForm.color} onChange={e => setEditSubjectForm({...editSubjectForm, color: e.target.value})} />
            </div>
            <div className="form-group full">
              <label>Image miniature</label>
              <div className="file-upload-row">
                <input type="file" accept="image/*" onChange={handleUploadThumbnail} id="edit-subject-thumb-upload" className="file-input-hidden" />
                <label htmlFor="edit-subject-thumb-upload" className="admin-btn ghost upload-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  {uploading ? 'Téléchargement...' : 'Télécharger une image depuis l\'appareil'}
                </label>
              </div>
              {editSubjectForm.thumbnail_url && (
                <div className="thumb-preview">
                  <img src={editSubjectForm.thumbnail_url} alt="preview" />
                </div>
              )}
              <input type="text" placeholder="Ou saisir manuellement le lien de l'image" value={editSubjectForm.thumbnail_url} onChange={e => setEditSubjectForm({...editSubjectForm, thumbnail_url: e.target.value})} style={{ marginTop: '8px' }} />
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => { setShowEditSubject(false); setEditingSubject(null); }}>Annuler</button>
            <button className="admin-btn primary" onClick={handleUpdateSubject}>Enregistrer les modifications</button>
          </div>
        </div>
      )}

      {showAddChapter && (
        <div className="admin-form-card">
          <h3>Ajouter une nouvelle unité</h3>
          {chapterFormError && <div className="error-alert">{chapterFormError}</div>}
          <div className="form-grid">
            <div className="form-group full">
              <label>Titre de l'unité</label>
              <input type="text" placeholder="Exemple : Unité 1" value={chapterTitle} onChange={e => setChapterTitle(e.target.value)} autoFocus />
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => setShowAddChapter(false)}>Annuler</button>
            <button className="admin-btn primary" onClick={handleAddChapter}>Enregistrer</button>
          </div>
        </div>
      )}

      {showEditChapter && editingChapter && (
        <div className="admin-form-card">
          <h3>Modifier l'unité</h3>
          {chapterFormError && <div className="error-alert">{chapterFormError}</div>}
          <div className="form-grid">
            <div className="form-group full">
              <label>Titre de l'unité</label>
              <input type="text" value={editChapterTitle} onChange={e => setEditChapterTitle(e.target.value)} autoFocus />
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => { setShowEditChapter(false); setEditingChapter(null); }}>Annuler</button>
            <button className="admin-btn primary" onClick={handleUpdateChapter}>Enregistrer</button>
          </div>
        </div>
      )}

      {showAddLesson && (
        <div className="admin-form-card">
          <h3>{editingLessonId ? 'Modifier la leçon' : 'Ajouter une nouvelle leçon'}</h3>
          {formError && <div className="error-alert">{formError}</div>}
          <div className="form-grid">
            <div className="form-group full">
              <label>Titre de la leçon</label>
              <input type="text" placeholder="Titre de la leçon" value={lessonForm.title} onChange={e => setLessonForm({...lessonForm, title: e.target.value})} />
            </div>
            <div className="form-group full">
              <label>Description</label>
              <textarea placeholder="Description de la leçon..." value={lessonForm.description} onChange={e => setLessonForm({...lessonForm, description: e.target.value})} rows="3"></textarea>
            </div>
            <div className="form-group">
              <label>Vidéo de la leçon</label>
              <div className="file-upload-row">
                <input type="file" accept="video/*" onChange={handleLessonVideoUpload} id="lesson-video-upload" className="file-input-hidden" />
                <label htmlFor="lesson-video-upload" className="admin-btn ghost upload-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  {uploadingVideo ? 'Téléchargement de la vidéo...' : 'Télécharger une vidéo depuis l\'appareil'}
                </label>
              </div>
              {lessonForm.video_url && (
                <div className="file-selected">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  Vidéo téléchargée
                </div>
              )}
              <input type="text" placeholder="Ou lien vidéo (facultatif)" value={lessonForm.video_url} onChange={e => setLessonForm({...lessonForm, video_url: e.target.value})} style={{ marginTop: '8px' }} />
            </div>
            <div className="form-group">
              <label>Durée (remplie automatiquement)</label>
              <input type="text" placeholder="10:30" value={lessonForm.video_duration} onChange={e => setLessonForm({...lessonForm, video_duration: e.target.value})} readOnly={!lessonForm.video_duration} />
              {lessonForm.video_duration && <div className="file-selected" style={{ marginTop: 6 }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>Durée calculée : {lessonForm.video_duration}</div>}
            </div>
            <div className="form-group">
              <label>Image miniature</label>
              <div className="file-upload-row">
                <input type="file" accept="image/*" onChange={handleLessonThumbUpload} id="lesson-thumb-upload" className="file-input-hidden" />
                <label htmlFor="lesson-thumb-upload" className="admin-btn ghost upload-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  {uploadingLessonThumb ? 'Téléchargement...' : 'Choisir une image depuis l\'appareil'}
                </label>
              </div>
              {lessonForm.thumbnail_url && (
                <div className="thumb-preview">
                  <img src={lessonForm.thumbnail_url} alt="preview" />
                </div>
              )}
              <input type="text" placeholder="Ou lien de l'image saisi manuellement" value={lessonForm.thumbnail_url} onChange={e => setLessonForm({...lessonForm, thumbnail_url: e.target.value})} style={{ marginTop: '8px' }} />
            </div>
            <div className="form-group">
              <label>Résumé de la leçon (PDF)</label>
              <div className="file-upload-row">
                <input type="file" accept="application/pdf" onChange={handleSummaryUpload} id="lesson-summary-upload" className="file-input-hidden" />
                <label htmlFor="lesson-summary-upload" className="admin-btn ghost upload-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  {uploadingSummary ? 'Téléchargement...' : 'Télécharger un résumé PDF'}
                </label>
              </div>
              {lessonForm.summary_url && (
                <div className="file-selected">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  Résumé téléchargé
                </div>
              )}
              <input type="text" placeholder="Ou lien PDF saisi manuellement" value={lessonForm.summary_url} onChange={e => setLessonForm({...lessonForm, summary_url: e.target.value})} style={{ marginTop: '8px' }} />
            </div>
            <div className="form-group">
              <label>Exercice de la leçon (PDF)</label>
              <div className="file-upload-row">
                <input type="file" accept="application/pdf" onChange={handleExerciseUpload} id="lesson-exercise-upload" className="file-input-hidden" />
                <label htmlFor="lesson-exercise-upload" className="admin-btn ghost upload-btn">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  {uploadingExercise ? 'Téléchargement...' : 'Télécharger un exercice PDF'}
                </label>
              </div>
              {lessonForm.exercise_url && (
                <div className="file-selected">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
                  Exercice téléchargé
                </div>
              )}
              <input type="text" placeholder="Ou lien PDF saisi manuellement" value={lessonForm.exercise_url} onChange={e => setLessonForm({...lessonForm, exercise_url: e.target.value})} style={{ marginTop: '8px' }} />
            </div>
            <div className="form-group">
              <label>Tags (séparés par une virgule)</label>
              <input type="text" placeholder="#_tag1,#tag2" value={lessonForm.tags} onChange={e => setLessonForm({...lessonForm, tags: e.target.value})} />
            </div>
          </div>
          <div className="form-actions">
            <button className="admin-btn ghost" onClick={() => setShowAddLesson(false)}>Annuler</button>
            <button className="admin-btn primary" onClick={handleAddLesson}>Enregistrer</button>
          </div>
        </div>
      )}

      <div className="courses-layout">
        <div className="courses-tree">
          {grouped.map(level => (
            <div className="tree-level" key={level.id}>
              <div className="tree-head" onClick={() => toggle(`lvl-${level.slug}`)}>
                <span className="chevron">{expanded[`lvl-${level.slug}`] ? '▾' : '▸'}</span>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                <strong>{level.name}</strong>
              </div>
              {expanded[`lvl-${level.slug}`] !== false && level.subjects.map(subject => (
                <div className="tree-subject" key={subject.id}>
                  <div className="tree-head" onClick={() => toggleSubject(subject)}>
                    <span className="chevron">{expanded[`sub-${subject.id}`] ? '▾' : '▸'}</span>
                    <span className="color-dot" style={{ background: subject.color }}></span>
                    <span>{subject.name}</span>
                    <span className="count">{subject.lesson_count}</span>
                  </div>
                  <div className="tree-actions">
                    <button className="tree-action-btn edit" title="Modifier la matière" onClick={(e) => { e.stopPropagation(); handleEditSubject(subject); }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                    <button className="tree-action-btn add" title="Ajouter une unité" onClick={(e) => { e.stopPropagation(); openAddChapter(subject.id); }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    </button>
                  </div>

                  {expanded[`sub-${subject.id}`] !== false && (
                    <div className="tree-chapters">
                      {treeData[subject.id] && treeData[subject.id].length > 0 ? (
                        treeData[subject.id].map(chapter => (
                          <div className="tree-chapter-block" key={chapter.id}>
                            <div className="tree-chapter-head">
                              <span className="chapter-folder">
                                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
                              </span>
                              <span className="chapter-title" onClick={() => toggle(`ch-${chapter.id}`)}>{chapter.title}</span>
                              <span className="count">{chapter.lessons ? chapter.lessons.length : ''}</span>
                              <div className="tree-actions">
                                <button className="tree-action-btn edit" title="Modifier l'unité" onClick={(e) => { e.stopPropagation(); openEditChapter(chapter); }}>
                                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                </button>
                                <button className="tree-action-btn add" title="Ajouter une leçon" onClick={(e) => { e.stopPropagation(); openAddLesson(chapter); }}>
                                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                </button>
                                <button className="tree-action-btn del" title="Supprimer l'unité" onClick={(e) => { e.stopPropagation(); handleDeleteChapter(chapter); }}>
                                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                </button>
                              </div>
                            </div>
                            {expanded[`ch-${chapter.id}`] !== false && chapter.lessons && chapter.lessons.length > 0 && (
                              <div className="tree-lessons">
                                {chapter.lessons.map(lesson => (
                                  <div className="tree-lesson" key={lesson.id}>
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 15l5.19-9L20 16.5M6 15l3.07-5.36M14.67 15H22"/></svg>
                                    <span className="lesson-title">{lesson.title}</span>
                                    <div className="tree-actions">
                                      <button className="tree-action-btn edit" title="Modifier la leçon" onClick={(e) => { e.stopPropagation(); openEditLesson(lesson, chapter.id); }}>
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                      </button>
                                      <button className="tree-action-btn del" title="Supprimer la leçon" onClick={(e) => { e.stopPropagation(); handleDeleteLesson(lesson, chapter.id); }}>
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                            {expanded[`ch-${chapter.id}`] !== false && (!chapter.lessons || chapter.lessons.length === 0) && (
                              <div className="tree-lessons-empty" onClick={() => openAddLesson(chapter)}>
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                Ajouter une leçon
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="tree-chapter-nodata" onClick={() => openAddChapter(subject.id)}>
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                          Ajouter une unité
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>

        <div className="courses-editor">
          <div className="editor-empty">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
            <h3>Organisez les matières, les unités et les leçons ici</h3>
            <p>Ouvrez une matière dans l'arborescence, ajoutez les unités puis les leçons</p>
          </div>
        </div>
      </div>
    </div>
  );
}
