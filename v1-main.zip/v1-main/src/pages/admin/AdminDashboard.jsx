import { useState, useEffect } from 'react';
import { getAdminStats, getAdminStudents, getUserActivity } from '../../api';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [students, setStudents] = useState([]);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getAdminStats(), getAdminStudents(), getUserActivity()])
      .then(([s, st, act]) => { setStats(s); setStudents(st); setActivity(act); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="admin-loading"><div className="spinner"></div>Chargement...</div>;
  if (!stats) return <div className="admin-loading">Erreur lors du chargement des données</div>;

  const overdueStudents = students.filter(s => s.status === 'overdue');
  const totalWatchHours = activity.reduce((sum, a) => sum + (a.total_hours || 0), 0);

  return (
    <div className="admin-content">
      <div className="admin-page-head">
        <h1>Tableau de bord</h1>
        <p>Vue d'ensemble de l'activité de la plateforme</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card blue">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div className="stat-body">
            <span className="stat-num">{stats.totalUsers}</span>
            <span className="stat-label">Utilisateur inscrit</span>
          </div>
        </div>
        <div className="stat-card green">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div className="stat-body">
            <span className="stat-num">{stats.activeStudents}</span>
            <span className="stat-label">Étudiant actif</span>
          </div>
        </div>
        <div className="stat-card orange">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          </div>
          <div className="stat-body">
            <span className="stat-num">{totalWatchHours.toFixed(1)}</span>
            <span className="stat-label">Heure de visionnage</span>
          </div>
        </div>
        <div className="stat-card red">
          <div className="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </div>
          <div className="stat-body">
            <span className="stat-num">{overdueStudents.length}</span>
            <span className="stat-label">Paiements en retard</span>
          </div>
        </div>
      </div>

      <div className="admin-grid-2">
        <div className="admin-card">
          <h3 className="admin-card-title">Utilisateurs les plus actifs</h3>
          <div className="activity-list">
            {activity.slice(0, 5).map((a, i) => (
              <div className="activity-row" key={i}>
                <div className="activity-avatar">{a.name.charAt(0)}</div>
                <div className="activity-info">
                  <strong>{a.name}</strong>
                  <span>{a.lessons_watched} leçon(s) · {a.total_hours} heure(s)</span>
                </div>
                <div className="activity-time">{a.last_active ? new Date(a.last_active).toLocaleDateString('fr-FR') : '—'}</div>
              </div>
            ))}
            {activity.length === 0 && <p className="empty-msg">Aucune activité pour le moment</p>}
          </div>
        </div>

        <div className="admin-card">
          <h3 className="admin-card-title">Paiements dus</h3>
          <div className="activity-list">
            {overdueStudents.slice(0, 5).map(s => (
              <div className="activity-row" key={s.id}>
                <div className="activity-avatar red">{s.name.charAt(0)}</div>
                <div className="activity-info">
                  <strong>{s.name}</strong>
                  <span>{s.level}</span>
                </div>
                <div className="activity-time overdue">En retard</div>
              </div>
            ))}
            {overdueStudents.length === 0 && <p className="empty-msg">Aucun paiement en retard</p>}
          </div>
        </div>
      </div>

      <div className="admin-card" style={{ marginTop: 24 }}>
        <h3 className="admin-card-title">Niveaux</h3>
        <div className="level-bars">
          {stats.byLevel.map(l => {
            const pct = l.students > 0 ? Math.round((l.active / l.students) * 100) : 0;
            return (
              <div className="level-bar-row" key={l.level}>
                <div className="level-bar-head">
                  <strong>{l.level}</strong>
                  <span>{l.active} actif(s) sur {l.students} · {pct}%</span>
                </div>
                <div className="level-bar-track">
                  <span style={{ width: `${pct}%` }}></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
