import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { loginUser } from '../api';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const user = await loginUser(form.email, form.password);
      if (user.error) {
        setError(user.error);
      } else {
        login(user);
        navigate('/');
      }
    } catch {
      setError('Erreur de connexion au serveur');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <div className="page-hero-icon">
            <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
              <polyline points="10 17 15 12 10 7"/>
              <line x1="15" y1="12" x2="3" y2="12"/>
            </svg>
          </div>
          <h1>Connexion</h1>
          <p>Entrez vos identifiants pour accéder à votre compte</p>
        </div>
      </section>

      <div className="container" style={{ padding: '48px 20px' }}>
        <div className="login-card">
          {error && <div className="error-msg">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="field">
              <label>Adresse e-mail</label>
              <input type="email" name="email" value={form.email} onChange={handleChange} placeholder="name@example.com" required />
            </div>
            <div className="field">
              <label>Mot de passe</label>
              <input type="password" name="password" value={form.password} onChange={handleChange} placeholder="••••••••" required />
            </div>
            <div className="field-row">
              <label><input type="checkbox" /> Se souvenir de moi</label>
              <span className="forgot-password">Mot de passe oublié ? Contactez l'administration</span>
            </div>
            <button type="submit" className="btn btn-orange btn-block" disabled={loading}>
              {loading ? 'Traitement...' : 'Se connecter'}
            </button>
          </form>
        </div>
      </div>
    </>
  );
}
