import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getLevels, getSubjects } from '../api';
import { useAuth } from '../context/AuthContext';

const subjectIcons = {
  'economie': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
    </svg>
  ),
  'comptabilite': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
    </svg>
  ),
  'maths': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
      <rect x="3" y="3" width="18" height="18" rx="2"/>
    </svg>
  ),
  'statistique': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
    </svg>
  ),
  'management': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  'default': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
    </svg>
  ),
};

const levelIcons = {
  'bac1': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>
    </svg>
  ),
  'bac2': (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/><circle cx="12" cy="10" r="2"/>
    </svg>
  ),
};

function getSubjectIcon(slug) {
  if (slug.includes('economie') || slug.includes('eco')) return subjectIcons['economie'];
  if (slug.includes('comptab') || slug.includes('compta')) return subjectIcons['comptabilite'];
  if (slug.includes('math')) return subjectIcons['maths'];
  if (slug.includes('stat')) return subjectIcons['statistique'];
  if (slug.includes('manage') || slug.includes('admin')) return subjectIcons['management'];
  return subjectIcons['default'];
}

export default function Courses() {
  const [searchParams] = useSearchParams();
  const activeLevel = searchParams.get('level');
  const { user } = useAuth();
  const [levels, setLevels] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    Promise.all([getLevels(), getSubjects()])
      .then(([l, s]) => { setLevels(l); setSubjects(s); })
      .catch(() => setError("Impossible de charger les cours. Veuillez réessayer."))
      .finally(() => setLoading(false));
  }, []);

  const grouped = levels.map(level => ({
    ...level,
    subjects: subjects.filter(s => s.level_slug === level.slug),
  }));

  let filtered = activeLevel ? grouped.filter(g => g.slug === activeLevel) : grouped;
  // Students linked to a level only see their own level's courses
  if (user && user.level_slug) filtered = filtered.filter(g => g.slug === user.level_slug);

  if (loading) return <div className="container loading">Chargement...</div>;
  if (error) return <div className="container"><p className="empty-note">{error}</p></div>;

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <div className="page-hero-icon">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
            </svg>
          </div>
          <h1>Nos cours</h1>
          <p>Choisissez votre niveau et commencez à naviguer directement — tous les cours sont disponibles sans inscription</p>
        </div>
      </section>

      <div className="container" style={{ padding: '48px 20px' }}>
        <div className="catalog-note">
          Vous pouvez consulter tous les cours et les regarder sans vous connecter. La connexion n'est requise que pour enregistrer votre progression et télécharger les fichiers.
        </div>

        {filtered.map(group => (
          <div key={group.id} id={group.slug}>
            <div className="catalog-level-head">
              <div className="catalog-level-icon">{levelIcons[group.slug] || levelIcons['bac1']}</div>
              <div>
                <h2>{group.name}</h2>
                <p>{group.subjects.length} matières disponibles</p>
              </div>
            </div>
            <div className="subjects-list">
              {group.subjects.map(subject => (
                <div key={subject.id} className="subject-card">
                  <div className="subject-icon-wrap" style={{ background: subject.color + '18' }}>
                    <div className="subject-icon" style={{ color: subject.color }}>
                      {getSubjectIcon(subject.slug)}
                    </div>
                  </div>
                  <div className="body">
                    <h3>{subject.name}</h3>
                    <div className="meta">{subject.lesson_count} leçons · vidéos, résumés, exercices</div>
                  </div>
                  <Link to={`/subject/${subject.slug}`} className="btn btn-ghost">Consulter</Link>
                </div>
              ))}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <p className="empty-note">Aucun cours disponible pour ce niveau.</p>
        )}
      </div>
    </>
  );
}
