import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getSubjects, getProgress } from '../api';

export default function Dashboard() {
  const { user } = useAuth();
  const [subjects, setSubjects] = useState([]);
  const [progress, setProgress] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!user) return;
    setError(false);
    const fetchPromise = user.level_slug
      ? Promise.all([getSubjects(user.level_slug), getProgress(user.id)])
      : Promise.all([getSubjects(), getProgress(user.id)]);
    fetchPromise
      .then(([s, p]) => { setSubjects(s); setProgress(p); })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, [user]);

  if (!user) {
    return (
      <div className="container" style={{ textAlign: 'center', padding: '80px 20px' }}>
        <h2>Vous devez d'abord vous connecter</h2>
        <Link to="/login" className="btn btn-orange" style={{ marginTop: 20 }}>Se connecter</Link>
      </div>
    );
  }

  const totalLessons = subjects.reduce((sum, s) => sum + s.lesson_count, 0);
  const completedLessons = progress.filter(p => p.completed).length;
  const percent = totalLessons ? Math.round((completedLessons / totalLessons) * 100) : 0;

  if (loading) return <div className="container loading">Chargement...</div>;
  if (error) return (
    <div className="container" style={{ textAlign: 'center', padding: '80px 20px' }}>
      <h2>Erreur de chargement</h2>
      <button className="btn btn-orange" style={{ marginTop: 20 }} onClick={() => window.location.reload()}>Réessayer</button>
    </div>
  );

  return (
    <div className="container">
      <div className="page-head">
        <h1>Bonjour {user.name}</h1>
        <p>Suivez vos leçons et votre progression dans chaque matière.</p>
      </div>

      <div className="overall-progress">
        <div className="top-row">
          <strong>Progression globale</strong>
          <span style={{ fontSize: 14, color: 'var(--green)', fontWeight: 700 }}>{percent}%</span>
        </div>
        <div className="progress-bar">
          <span style={{ width: `${percent}%` }}></span>
        </div>
      </div>

      <div className="section-head" style={{ textAlign: 'left', marginBottom: 20 }}>
        <h2 style={{ fontSize: 20 }}>Matières disponibles</h2>
      </div>

      <div className="courses">
        {subjects.map(subject => (
          <Link key={subject.id} to={`/subject/${subject.slug}`} className="course-card">
            <div className="course-thumb" style={{ background: subject.color }}>
              {subject.thumbnail_url ? <img src={subject.thumbnail_url} alt={subject.name} className="course-thumb-img" /> : subject.icon}
            </div>
            <div className="course-body">
              <h3>{subject.name}</h3>
              <div className="meta">{subject.lesson_count} leçons · {subject.level_name}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
