import { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('ae_user');
    if (!saved) return null;
    try { return JSON.parse(saved); }
    catch { localStorage.removeItem('ae_user'); return null; }
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('ae_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('ae_user');
    }
  }, [user]);

  const login = (userData) => setUser(userData);
  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
